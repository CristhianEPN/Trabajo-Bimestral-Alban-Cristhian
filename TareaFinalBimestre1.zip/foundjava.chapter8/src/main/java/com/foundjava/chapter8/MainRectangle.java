package com.foundjava.chapter8;

import java.awt.Point;
public class MainRectangle {
    public static void main(String[] args) {
        // Crear una instancia de la clase Rectangle
        Point location = new Point(15, 25);
        int height = 10;
        int width = 20;
        Rectangle myRectangle = new Rectangle(location, height, width);
        
        // Utilizar los métodos heredados getHeight y getWidth
        System.out.println("Dimensiones iniciales del rectángulo:");
        System.out.println("Altura: " + myRectangle.getHeight());
        System.out.println("Ancho: " + myRectangle.getWidth());
        
        // Utilizar el método heredado setDimensions
        int[] newDimensions = {15, 30};
        myRectangle.setDimensions(newDimensions);
        
        System.out.println("\nNuevas dimensiones del rectángulo:");
        System.out.println("Altura: " + myRectangle.getHeight());
        System.out.println("Ancho: " + myRectangle.getWidth());
    }
}
