package com.foundjava.chapter8;

import java.awt.Graphics;
import java.awt.Point;

public class Circle extends OneDimensionalShape implements Drawable {
    
    public Circle(Point location, int radius) {
        super(location, radius);
    }
    
    @Override
    public double getArea() {
        return (Math.PI * (Math.pow(this.getDimension(), 2.0)));
    }
    
    @Override
    public void draw(Graphics g) {
        g.fillOval(getLocation().x, getLocation().y, 
                   getDimension(), getDimension());
    }
}