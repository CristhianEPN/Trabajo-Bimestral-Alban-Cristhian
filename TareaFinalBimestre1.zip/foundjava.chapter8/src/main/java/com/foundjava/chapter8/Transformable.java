package com.foundjava.chapter8;

public interface Transformable {
	public void switchDimensions();
}
