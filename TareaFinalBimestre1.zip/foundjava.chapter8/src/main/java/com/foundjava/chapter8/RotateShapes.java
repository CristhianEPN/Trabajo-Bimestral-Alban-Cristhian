package com.foundjava.chapter8;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JFrame;

public class RotateShapes extends JFrame {
    
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        
        Shape[] shapes = {
            new Rectangle(new Point(50, 50), 30, 60),
            new Oval(new Point(150, 50), 40, 80),
            new RightAngledTriangle(new Point(250, 50), 50, 30)
        };
        
        int yOffset = 0;
        for (Shape shape : shapes) {
            // Dibujar forma original
            g.setColor(Color.BLUE);
            shape.draw(g);
            
            // Rotar 90° y dibujar
            shape.rotate();
            shape.setLocation(new Point(shape.getLocation().x, 
                                       shape.getLocation().y + 100));
            g.setColor(Color.RED);
            shape.draw(g);
            
            // Rotar 180° (total 270°) y dibujar
            shape.rotate180();
            shape.setLocation(new Point(shape.getLocation().x, 
                                       shape.getLocation().y + 100));
            g.setColor(Color.GREEN);
            shape.draw(g);
        }
    }
    
    public static void main(String[] args) {
        RotateShapes frame = new RotateShapes();
        frame.setTitle("Rotating Shapes");
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}