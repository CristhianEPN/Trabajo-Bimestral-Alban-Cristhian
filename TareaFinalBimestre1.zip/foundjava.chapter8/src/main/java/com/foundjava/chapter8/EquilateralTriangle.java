package com.foundjava.chapter8;

//Ejercicio 8.4
import java.awt.Graphics;
import java.awt.Point;

public class EquilateralTriangle extends OneDimensionalShape implements Drawable {
    
    public EquilateralTriangle(Point location, int side) {
        super(location, side);
    }
    
    @Override
    public double getArea() {
        double side = getDimension();
        return (Math.sqrt(3) / 4) * Math.pow(side, 2);
    }
    
    @Override
    public void draw(Graphics g) {
        int xLocation = this.getLocation().x;
        int yLocation = this.getLocation().y;
        int side = getDimension();
        int height = (int) ((Math.sqrt(3) / 2) * side);
        
        int[] xValues = {
            xLocation,
            xLocation + side,
            xLocation + side / 2
        };
        
        int[] yValues = {
            yLocation + height,
            yLocation + height,
            yLocation
        };
        
        g.fillPolygon(xValues, yValues, 3);
    }
}