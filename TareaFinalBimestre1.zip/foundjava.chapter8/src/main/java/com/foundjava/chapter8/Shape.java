package com.foundjava.chapter8;

import java.awt.Point;

public abstract class Shape implements Rotable {
    protected Point location;
    protected int[] dimensions;
    
    public Shape(Point location) {
        setLocation(location);
    }
    
    public int[] getDimensions() {
        return dimensions;
    }
    
    public void setDimensions(int[] dim) {
        this.dimensions = dim;
    }
    
    public Point getLocation() {
        return location;
    }
    
    public void setLocation(Point location) {
        this.location = location;
    }
    
    @Override
    public void rotate() {
        int oldX = this.location.x;
        int oldY = this.location.y;
        this.location = new Point(oldY, oldX);
    }
    
    @Override
    public void rotate180() {
        rotate();
        rotate();
    }
    
    @Override
    public void rotate270() {
        rotate180();
        rotate();
    }
    
    @Override
    public void rotateCounterClockwise() {
        rotate270();
    }
    
    public abstract double getArea();
}