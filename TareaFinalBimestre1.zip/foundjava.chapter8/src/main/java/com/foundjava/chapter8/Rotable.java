package com.foundjava.chapter8;

public interface Rotable {
	public void rotate();         
    public void rotate180();       
    public void rotate270();        
    public void rotateCounterClockwise();
    }
