package com.foundjava.chapter8;

import java.awt.Point;

public class MainCircle {
    
    public static void main(String[] args) {
        // Crear una instancia de la clase Circle
        Point location = new Point(10, 20);
        int radius = 5;
        Circle myCircle = new Circle(location, radius);
        
        // Utilizar el método heredado getDimension
        System.out.println("Dimensión del círculo (radio): " + myCircle.getDimension());
        
        // Utilizar el método heredado setDimensions
        int[] newDimension = {7};
        myCircle.setDimensions(newDimension);
        
        System.out.println("Nueva dimensión del círculo (radio): " + myCircle.getDimension());
        
        // Mostrar la ubicación del círculo
        Point circleLocation = myCircle.getLocation();
        System.out.println("Ubicación del círculo: (" + circleLocation.x + ", " + circleLocation.y + ")");
        
        // Cambiar la ubicación
        myCircle.setLocation(new Point(30, 40));
        Point newLocation = myCircle.getLocation();
        System.out.println("Nueva ubicación del círculo: (" + newLocation.x + ", " + newLocation.y + ")");
    }
}
