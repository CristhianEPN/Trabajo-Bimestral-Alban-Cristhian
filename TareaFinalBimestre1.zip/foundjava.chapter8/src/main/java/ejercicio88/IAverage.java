package ejercicio88;

public interface IAverage {

    double getMean(double[] data);


     
    private double calculateMean(double[] data) {
        if (data == null || data.length == 0) {
            return 0.0;
        }
        double sum = 0;
        for (double value : data) {
            sum += value;
        }
        // Devuelve la suma dividida por el número de elementos.
        return sum / data.length;
    }

    default double getMean() {

        double[] data = getDataArray();
        System.out.println("-> Llamando al método predeterminado getMean().");
        System.out.println("-> El método predeterminado llama al método privado calculateMean().");
        return calculateMean(data);
    }

    double[] getDataArray();
    
    double getAverage(double[] data);

}