package ejercicio88;

public class StatisticsWithoutMean implements IAverage {

    private double[] data = {1.0, 2.0, 3.0, 4.0, 5.0};

    @Override
    public double[] getDataArray() {
        System.out.println("-> La clase DataProcessor proporciona los datos.");
        return this.data;
    }

}