package ejercicio88;


import java.util.Arrays;
public class Main {

    public static void main(String[] args) {
        double[] numbers = {4.0, 1.0, 7.0, 3.0, 5.0};
        System.out.println("Array de números original: " + Arrays.toString(numbers));
        System.out.println("----------------------------------------");

        IAverage meanCalculator = (data) -> {
            double sum = 0;
            for (double value : data) {
                sum += value;
            }
            return sum / data.length;
        };

        double mean = meanCalculator.getAverage(numbers);
        System.out.println("🔢 Media Calculada (Promedio): " + mean);
        System.out.println("----------------------------------------");

        IAverage medianCalculator = (data) -> {
            // Se debe trabajar sobre una copia para no modificar el array original
            double[] sortedData = Arrays.copyOf(data, data.length);
            Arrays.sort(sortedData);

            int n = sortedData.length;

            if (n % 2 != 0) {
                // Si la longitud es impar, la mediana es el valor central
                return sortedData[n / 2];
            } else {
                // Si la longitud es par, la mediana es el promedio de los dos valores centrales
                int middle1 = n / 2 - 1;
                int middle2 = n / 2;
                return (sortedData[middle1] + sortedData[middle2]) / 2.0;
            }
        };

        double median = medianCalculator.getAverage(numbers);
        System.out.println("🔢 Mediana Calculada: " + median);
        System.out.println("----------------------------------------");

    }
}