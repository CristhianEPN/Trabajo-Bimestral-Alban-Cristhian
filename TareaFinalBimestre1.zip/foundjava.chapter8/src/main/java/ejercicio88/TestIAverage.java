package ejercicio88;

public class TestIAverage {
    
    public static void main(String[] args) {
        // Crear un array de números de prueba
        double[] numbers = {10.5, 20.3, 15.7, 30.2, 25.8, 18.9};
        
        // Crear una instancia de la clase que implementa IAverage
        StatisticsWithoutMean stats = new StatisticsWithoutMean();
        
        System.out.println("Array de números:");
        for (double num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println("\n");
        
        // Llamar al método getMean() (usará la implementación predeterminada)
        double mean = stats.getMean(numbers);
        System.out.println("Media (usando método predeterminado): " + mean);
        
        // Llamar a otros métodos de la clase
        double median = stats.getMedian(numbers);
        System.out.println("Mediana: " + median);
        
        double range = stats.getRange(numbers);
        System.out.println("Rango: " + range);
        
        // Demostrar que funciona con diferentes arrays
        System.out.println("\n--- Probando con otro array ---");
        double[] numbers2 = {5.0, 10.0, 15.0, 20.0, 25.0};
        
        System.out.println("Media: " + stats.getMean(numbers2));
        System.out.println("Mediana: " + stats.getMedian(numbers2));
        System.out.println("Rango: " + stats.getRange(numbers2));
        
        // Probar con array vacío
        System.out.println("\n--- Probando con array vacío ---");
        double[] emptyArray = {};
        System.out.println("Media de array vacío: " + stats.getMean(emptyArray));
        
        
        
    }
}