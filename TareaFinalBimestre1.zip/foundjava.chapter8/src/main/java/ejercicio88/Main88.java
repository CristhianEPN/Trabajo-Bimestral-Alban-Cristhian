package ejercicio88;

public class Main88 {

    public static void main(String[] args) {
        // Crea una instancia de la clase que implementa la interfaz
        IAverage processor = new DataProcessor();
        
        
        double mean = processor.getMean();

        // Muestra el resultado
        System.out.println("\n✅ Resultado de la media: " + mean);
        
    }
}