package Ejercicio2;

public class PruebaCuadrilatero {

    public static void main(String[] args) {
        
        // Puntos de ejemplo (se mantienen igual)
        Punto pA = new Punto(0.0, 0.0);
        Punto pB = new Punto(10.0, 0.0);
        Punto pC = new Punto(8.0, 5.0);
        Punto pD = new Punto(2.0, 5.0);
        
        // Puntos para un rectángulo (10 x 5)
        Punto r1 = new Punto(0.0, 0.0);
        Punto r2 = new Punto(10.0, 0.0);
        Punto r3 = new Punto(10.0, 5.0);
        Punto r4 = new Punto(0.0, 5.0);
        
        // Puntos para un cuadrado (5 x 5)
        Punto c1 = new Punto(0.0, 0.0);
        Punto c2 = new Punto(5.0, 0.0);
        Punto c3 = new Punto(5.0, 5.0);
        Punto c4 = new Punto(0.0, 5.0);
        

        Trapezoide trapezoide = new Trapezoide(pA, pB, pC, pD);
        Paralelogramo paralelogramo = new Paralelogramo(pA, pB, pC, pD);
        Rectangulo rectangulo = new Rectangulo(r1, r2, r3, r4);
        Cuadrado cuadrado = new Cuadrado(c1, c2, c3, c4);


        System.out.println("--- CÁLCULO DE ÁREAS (SIN HERENCIA) ---");
        System.out.printf("Área de Trapezoide: %.2f%n", trapezoide.obtenerArea());
        System.out.printf("Área de Paralelogramo: %.2f%n", paralelogramo.obtenerArea());
        System.out.printf("Área de Rectangulo: %.2f%n", rectangulo.obtenerArea());
        System.out.printf("Área de Cuadrado: %.2f%n", cuadrado.obtenerArea());
    }
}