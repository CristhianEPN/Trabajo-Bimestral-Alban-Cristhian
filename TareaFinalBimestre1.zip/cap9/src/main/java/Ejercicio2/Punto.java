package Ejercicio2;

public class Punto {
    private double x;
    private double y;

    public Punto(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double obtenerX() { return x; }
    public double obtenerY() { return y; }
}