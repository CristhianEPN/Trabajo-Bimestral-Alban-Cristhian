package ejercicio1;

//Programa de Prueba PruebaComposicion.java
public class PruebaComposicion {

  public static void main( String args[] ) {
      
      EmpleadoBaseMasComisionComp empleado = 
          new EmpleadoBaseMasComisionComp( 
              "Bob", 
              "Lewis", 
              "333-33-3333", 
              5000, 
              .04, 
              300 );

      System.out.println( "--- DATOS INICIALES (Obtenidos por delegación) ---" );
      System.out.printf("Nombre: %s %s%n", 
          empleado.obtenerPrimerNombre(), 
          empleado.obtenerApellidoPaterno() ); 
      System.out.printf( "Ingresos Brutos (%.2f + comisión): $%.2f%n", 
          empleado.obtenerSalarioBase(), empleado.ingresos() );

      System.out.println( "\n--- MODIFICANDO VALORES ---" );
      empleado.establecerVentasBrutas( 10000.0 );
      empleado.establecerSalarioBase( 1000.0 ); 

      System.out.println( "\n--- INFORMACIÓN ACTUALIZADA (toString) ---" );
      System.out.println( empleado.toString() );
  } 
}