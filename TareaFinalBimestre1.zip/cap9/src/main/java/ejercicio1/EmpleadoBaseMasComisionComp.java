package ejercicio1;

//Ejercicio 9.3
import Deitel.cap9.EmpleadoPorComision3;
import Deitel.cap9.EmpleadoPorComision4;
public class EmpleadoBaseMasComisionComp {
	 private EmpleadoPorComision3 empleadoComision;
	 private double salarioBase; 

	 public EmpleadoBaseMasComisionComp(String nombre, String apellido, 
	     String nss, double ventas, double tarifa, double salario) 
	 {
	     empleadoComision = new EmpleadoPorComision3(nombre, apellido, nss, ventas, tarifa);
	     establecerSalarioBase(salario);
	 } 

	 public String obtenerPrimerNombre() {
	     return empleadoComision.obtenerPrimerNombre();
	 }
	 
	 public void establecerVentasBrutas(double ventas) {
	     empleadoComision.establecerVentasBrutas(ventas);
	 }
	 public void establecerSalarioBase(double salario) {
	     salarioBase = (salario < 0.0) ? 0.0 : salario;
	 }
	 
	 public double obtenerSalarioBase() {
	     return salarioBase;
	 }
	 public double ingresos() { 
	     return obtenerSalarioBase() + empleadoComision.ingresos(); 
	 } 

	 public String toString() { 
	     return String.format("%s\n%s: %.2f", 
	         empleadoComision.toString(), 
	         "salario base", obtenerSalarioBase());
	 }
	 public String obtenerApellidoPaterno() {
		    return empleadoComision.obtenerApellidoPaterno();
	 }
	}