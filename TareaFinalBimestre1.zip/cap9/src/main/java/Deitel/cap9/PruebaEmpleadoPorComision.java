package Deitel.cap9;

//Fig. 9.5 | Programa de prueba de la clase EmpleadoPorComision.
public class PruebaEmpleadoPorComision
{
 public static void main( String args[] )
 {
     // crea instancia de objeto EmpleadoPorComision
     EmpleadoPorComision empleado = 
         new EmpleadoPorComision( "Sue", "Jones", "222-22-2222", 10000, .06 );

     // obtiene datos del empleado por comisión
     System.out.println(
         "Informacion del empleado obtenida por los metodos establecer: \n" );
     System.out.printf( "%s %s%n", "El primer nombre es",
         empleado.obtenerPrimerNombre() );
     System.out.printf( "%s %s%n", "El apellido paterno es",
         empleado.obtenerApellidoPaterno() );
     System.out.printf( "%s %s%n", "El numero de seguro social es",
         empleado.obtenerNumeroSeguroSocial() );
     System.out.printf( "%s %.2f%n", "Las ventas brutas son",
         empleado.obtenerVentasBrutas() );
     System.out.printf( "%s %.2f%n", "La tarifa de comision es",
         empleado.obtenerTarifaComision() );

     // establece las ventas brutas
     empleado.establecerVentasBrutas( 500.0 ); 
     // establece la tarifa de comisión
     empleado.establecerTarifaComision( .1 );

     System.out.println( "\nInformacion actualizada del empleado, obtenida mediante toString" );
     System.out.println( empleado );
 } // fin de main
} // fin de la clase PruebaEmpleadoPorComision