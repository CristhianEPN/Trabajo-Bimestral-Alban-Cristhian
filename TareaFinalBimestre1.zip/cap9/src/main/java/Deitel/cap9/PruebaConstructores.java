package Deitel.cap9;

//Fig. 9.17: PruebaConstructores.java
//Muestra el orden en el que se llaman los constructores de la superclase y la subclase.
public class PruebaConstructores
{
 public static void main( String args[] )
 {
     // Se crea la instancia de la superclase
     EmpleadoPorComision4 empleado1 = new EmpleadoPorComision4(
         "Bob", "Lewis", "333-33-3333", 5000, .04 );

     System.out.println(); // Imprime línea en blanco

     // Se crea la instancia de la subclase
     EmpleadoBaseMasComision5 empleado2 =
         new EmpleadoBaseMasComision5(
             "Lisa", "Jones", "555-55-5555", 2000, .06, 800 );

     System.out.println(); // Imprime línea en blanco
     
     // Se crea otra instancia de la subclase
     EmpleadoBaseMasComision5 empleado3 =
         new EmpleadoBaseMasComision5(
             "Mark", "Sands", "888-88-8888", 8000, .15, 2000 );
 } // fin de main
} // fin de la clase PruebaConstructores