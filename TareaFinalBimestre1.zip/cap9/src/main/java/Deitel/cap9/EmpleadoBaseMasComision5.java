package Deitel.cap9;

//Fig. 9.16: EmpleadoBaseMasComision5.java
//Declaración de la clase EmpleadoBaseMasComision5.
public class EmpleadoBaseMasComision5 extends EmpleadoPorComision4
{
 private double salarioBase; // salario base por semana

 // constructor con seis argumentos
 public EmpleadoBaseMasComision5( String nombre, String apellido,
     String nss, double ventas, double tarifa, double salario )
 {
     super( nombre, apellido, nss, ventas, tarifa ); // Llama al constructor de la superclase
     establecerSalarioBase( salario ); // valida y almacena el salario base

     System.out.printf(
         "\nConstructor de EmpleadoBaseMasComision5:\n%s\n\n", this ); // Línea de impresión
 } // fin del constructor de EmpleadoBaseMasComision5 con seis argumentos

 // establece el salario base
 public void establecerSalarioBase( double salario )
 {
     salarioBase = ( salario < 0.0 ) ? 0.0 : salario;
 } // fin del método establecerSalarioBase

 // devuelve el salario base
 public double obtenerSalarioBase()
 {
     return salarioBase;
 } // fin del método obtenerSalarioBase

 // calcula los ingresos
 public double ingresos()
 {
     return obtenerSalarioBase() + super.ingresos();
 } // fin del método ingresos

 // devuelve representación String de EmpleadoBaseMasComision5
 public String toString()
 {
     return String.format( "%s\n%s: %.2f", 
         super.toString(), 
         "sueldo base", obtenerSalarioBase() );
 } // fin del método toString
} // fin de la clase EmpleadoBaseMasComision5