package Deitel.cap9;

//Fig. 9.4: EmpleadoPorComision.java
//La clase EmpleadoPorComision representa a un empleado por comisión.
public class EmpleadoPorComision extends Object
{
 private String primerNombre;
 private String apellidoPaterno;
 private String numeroSeguroSocial;
 private double ventasBrutas;     // ventas semanales totales
 private double tarifaComision;   // porcentaje de comisión

 // constructor con cinco argumentos
 public EmpleadoPorComision( String nombre, String apellido, String nss,
     double ventas, double tarifa )
 {
     // la llamada implícita al constructor del objeto ocurre aquí
     primerNombre = nombre;
     apellidoPaterno = apellido;
     numeroSeguroSocial = nss;
     establecerVentasBrutas( ventas );     // valida y almacena las ventas brutas
     establecerTarifaComision( tarifa );   // valida y almacena la tarifa de comisión
 } // fin del constructor de EmpleadoPorComision con cinco argumentos

 // establece el primer nombre
 public void establecerPrimerNombre( String nombre )
 {
     primerNombre = nombre;
 } // fin del método establecerPrimerNombre

 // devuelve el primer nombre
 public String obtenerPrimerNombre()
 {
     return primerNombre;
 } // fin del método obtenerPrimerNombre

 // establece el apellido paterno
 public void establecerApellidoPaterno( String apellido )
 {
     apellidoPaterno = apellido;
 } // fin del método establecerApellidoPaterno

 // devuelve el apellido paterno
 public String obtenerApellidoPaterno()
 {
     return apellidoPaterno;
 } // fin del método obtenerApellidoPaterno

 // establece el número de seguro social
 public void establecerNumeroSeguroSocial( String nss )
 {
     numeroSeguroSocial = nss; // debe validar
 } // fin del método establecerNumeroSeguroSocial

 // devuelve el número de seguro social
 public String obtenerNumeroSeguroSocial()
 {
     return numeroSeguroSocial;
 } // fin del método obtenerNumeroSeguroSocial

 // establece el monto de ventas totales del empleado por comisión
 public void establecerVentasBrutas( double ventas )
 {
     ventasBrutas = ( ventas < 0.0 ) ? 0.0 : ventas;
 } // fin del método establecerVentasBrutas

 // devuelve el monto de ventas totales del empleado por comisión
 public double obtenerVentasBrutas()
 {
     return ventasBrutas;
 } // fin del método obtenerVentasBrutas

 // establece la tarifa del empleado por comisión
 public void establecerTarifaComision( double tarifa )
 {
     tarifaComision = ( tarifa > 0.0 && tarifa < 1.0 ) ? tarifa : 0.0;
 } // fin del método establecerTarifaComision

 // devuelve la tarifa del empleado por comisión
 public double obtenerTarifaComision()
 {
     return tarifaComision;
 } // fin del método obtenerTarifaComision

 // calcula el salario del empleado por comisión
 public double ingresos()
 {
     return tarifaComision * ventasBrutas;
 } // fin del método ingresos

 // devuelve representación String del objeto EmpleadoPorComision
 public String toString()
 {
     return String.format( "%s: %s %s\n%s: %s\n%s: %.2f\n%s: %.2f",
         "empleado por comision", primerNombre, apellidoPaterno,
         "numero de seguro social", numeroSeguroSocial,
         "ventas brutas", ventasBrutas,
         "tarifa de comision", tarifaComision );
 } // fin del método toString
} // fin de la clase EmpleadoPorComision