package Deitel.cap9;

//Fig. 9.13: EmpleadoBaseMasComision4.java
//La clase EmpleadoBaseMasComision4 hereda de EmpleadoPorComision3 y
//accede a los datos private de EmpleadoPorComision3 a través de los
//métodos public de EmpleadoPorComision3.
public class EmpleadoBaseMasComision4 extends EmpleadoPorComision3
{
 private double salarioBase; // salario base por semana

 // constructor con seis argumentos
 public EmpleadoBaseMasComision4( String nombre, String apellido,
     String nss, double ventas, double tarifa, double salario )
 {
     super( nombre, apellido, nss, ventas, tarifa ); // llama al constructor de la superclase
     establecerSalarioBase( salario ); // valida y almacena el salario base
 } // fin del constructor de EmpleadoBaseMasComision4 con seis argumentos

 // establece el salario base
 public void establecerSalarioBase( double salario )
 {
     salarioBase = ( salario < 0.0 ) ? 0.0 : salario;
 } // fin del método establecerSalarioBase

 // devuelve el salario base
 public double obtenerSalarioBase()
 {
     return salarioBase;
 } // fin del método obtenerSalarioBase

 // calcula los ingresos
 public double ingresos()
 {
     // Usa el método ingresos() de la superclase para calcular la comisión
     return obtenerSalarioBase() + super.ingresos(); 
 } // fin del método ingresos

 // devuelve representación String de EmpleadoBaseMasComision4
 public String toString()
 {
     return String.format( "%s\n%s: %.2f", 
         super.toString(), 
         "salario base", obtenerSalarioBase() );
 } // fin del método toString
} // fin de la clase EmpleadoBaseMasComision4