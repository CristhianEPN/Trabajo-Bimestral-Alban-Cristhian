package Ejercicio13;

public class PruebaRacional {

    public static void main(String[] args) {
        System.out.println("--- 1. PRUEBA DE CONSTRUCTORES Y REDUCCIÓN ---");

        Racional r1 = new Racional(2, 4);
        System.out.printf("R1 (2/4 inicial): %s%n", r1); 

        Racional r2 = new Racional(-10, 30);
        System.out.printf("R2 (-10/30 inicial): %s%n", r2); 

        Racional r3 = new Racional();
        System.out.printf("R3 (predeterminado): %s%n", r3);

        Racional a = new Racional(1, 2);
        Racional b = new Racional(1, 3);
        System.out.printf("\nUsaremos A = %s y B = %s%n", a, b);

        Racional suma = a.sumar(b);
        System.out.println("\n--- 2. SUMA (1/2 + 1/3) ---");
        System.out.printf("Resultado: %s%n", suma); 
        System.out.printf("Decimal (3 dígitos): %s%n", suma.aPuntoFlotante(3)); 

        Racional resta = a.restar(b);
        System.out.println("\n--- 3. RESTA (1/2 - 1/3) ---");
        System.out.printf("Resultado: %s%n", resta);
        System.out.printf("Decimal (5 dígitos): %s%n", resta.aPuntoFlotante(5));

        Racional c = new Racional(1, 4);
        Racional multiplicacion = a.multiplicar(c);
        System.out.println("\n--- 4. MULTIPLICACIÓN (1/2 * 1/4) ---");
        System.out.printf("Resultado: %s%n", multiplicacion); 

        Racional division = a.dividir(c);
        System.out.println("\n--- 5. DIVISIÓN (1/2 / 1/4) ---");
        System.out.printf("Resultado: %s%n", division); 

        Racional sumaReducida = a.sumar(a);
        System.out.println("\n--- 6. PRUEBA DE REDUCCIÓN POST-OPERACIÓN ---");
        System.out.printf("1/2 + 1/2 = %s%n", sumaReducida); 
        System.out.println("\n--- 7. PRUEBA DE PUNTO FLOTANTE ---");
        Racional piAprox = new Racional(22, 7);
        System.out.printf("%s en 2 dígitos: %s%n", piAprox, piAprox.aPuntoFlotante(2));
        System.out.printf("%s en 6 dígitos: %s%n", piAprox, piAprox.aPuntoFlotante(6));
    }
}