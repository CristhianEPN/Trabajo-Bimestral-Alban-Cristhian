package Ejercicio13;

public class Racional {
    
    private int numerador;
    private int denominador;
    private static int calcularMCD(int a, int b) {
        a = Math.abs(a);
        b = Math.abs(b);
        
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    private void reducir() {
        if (numerador == 0) {
            denominador = 1;
            return;
        }
        int mcd = calcularMCD(numerador, denominador);
        
        numerador /= mcd;
        denominador /= mcd;
        if (denominador < 0) {
            numerador *= -1;
            denominador *= -1;
        }
    }

    public Racional() {
        this(0, 1);
    }

    public Racional(int num, int den) {
        if (den == 0) {
            throw new IllegalArgumentException("El denominador no puede ser cero.");
        }
        this.numerador = num;
        this.denominador = den;
        reducir();
    }

    public Racional sumar(Racional otro) {
        int nuevoNum = this.numerador * otro.denominador + otro.numerador * this.denominador;
        int nuevoDen = this.denominador * otro.denominador;
        return new Racional(nuevoNum, nuevoDen);
    }

    public Racional restar(Racional otro) {
        int nuevoNum = this.numerador * otro.denominador - otro.numerador * this.denominador;
        int nuevoDen = this.denominador * otro.denominador;
        return new Racional(nuevoNum, nuevoDen);
    }

    public Racional multiplicar(Racional otro) {
        int nuevoNum = this.numerador * otro.numerador;
        int nuevoDen = this.denominador * otro.denominador;
        return new Racional(nuevoNum, nuevoDen);
    }
    
    public Racional dividir(Racional otro) {
        if (otro.numerador == 0) {
            throw new ArithmeticException("División por cero (el divisor es cero).");
        }

        int nuevoNum = this.numerador * otro.denominador;
        int nuevoDen = this.denominador * otro.numerador;
        return new Racional(nuevoNum, nuevoDen);
    }

    @Override
    public String toString() {
        return String.format("%d/%d", numerador, denominador);
    }

    public String aPuntoFlotante(int precision) {
        double valorDecimal = (double) numerador / denominador;
        return String.format("%." + precision + "f", valorDecimal);
    }
}