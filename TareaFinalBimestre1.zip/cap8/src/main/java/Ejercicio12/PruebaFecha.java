package Ejercicio12;

public class PruebaFecha {
    
    public static void main(String[] args) {
        
        System.out.println("--- PRUEBA 1: CONSTRUCTOR 1 (MM/DD/AAAA) ---");
        try {
            Fecha f1 = new Fecha(6, 15, 1992);
            imprimirFormatos(f1);
        } catch (IllegalArgumentException e) {
            System.err.println("Error en Constructor 1: " + e.getMessage());
        }

        System.out.println("\n--- PRUEBA 2: CONSTRUCTOR 2 (Nombre, DD, AAAA) ---");
        try {
            Fecha f2 = new Fecha("DICIEMBRE", 25, 2024);
            imprimirFormatos(f2);
        } catch (IllegalArgumentException e) {
            System.err.println("Error en Constructor 2: " + e.getMessage());
        }

        System.out.println("\n--- PRUEBA 3: CONSTRUCTOR 3 (DDD AAAA) ---");
        try {
            Fecha f3 = new Fecha(60, 2024);
            imprimirFormatos(f3);
        } catch (IllegalArgumentException e) {
            System.err.println("Error en Constructor 3: " + e.getMessage());
        }
        
        System.out.println("\n--- PRUEBA 4: CONSTRUCTOR INVÁLIDO ---");
        try {
            new Fecha(2, 30, 2025);
        } catch (IllegalArgumentException e) {
            System.err.println("Error de Validación: " + e.getMessage());
        }
    }
    
    public static void imprimirFormatos(Fecha f) {
        System.out.printf("  F1 (MM/DD/AAAA): %s%n", f.aFormato1());
        System.out.printf("  F2 (Nombre DD, AAAA): %s%n", f.aFormato2());
        System.out.printf("  F3 (DDD AAAA): %s%n", f.aFormato3());
    }
}