package Ejercicio12;

import java.util.Arrays;
import java.util.List;

public class Fecha {
    private int mes; 
    private int dia;
    private int anio;

    private static final List<String> NOMBRES_MESES = Arrays.asList(
        "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO",
        "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"
    );

    private static final int[] DIAS_POR_MES = 
        { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

    private boolean esBisiesto(int anioPrueba) {
        return (anioPrueba % 400 == 0) || (anioPrueba % 4 == 0 && anioPrueba % 100 != 0);
    }

    private void validarFecha(int m, int d, int a) {
        if (m < 1 || m > 12 || a < 1) {
            throw new IllegalArgumentException("Mes o año inválido.");
        }
        
        int diasMaximos = DIAS_POR_MES[m];
        if (m == 2 && esBisiesto(a)) {
            diasMaximos = 29;
        }

        if (d < 1 || d > diasMaximos) {
            throw new IllegalArgumentException("Día inválido para el mes/año especificado.");
        }
        
        this.mes = m;
        this.dia = d;
        this.anio = a;
    }

    public Fecha(int mes, int dia, int anio) {
        validarFecha(mes, dia, anio);
    }

    public Fecha(String nombreMes, int dia, int anio) {
        int m = -1;
        for (int i = 0; i < NOMBRES_MESES.size(); i++) {
            if (NOMBRES_MESES.get(i).equalsIgnoreCase(nombreMes)) {
                m = i + 1;
                break;
            }
        }
        
        if (m == -1) {
            throw new IllegalArgumentException("Nombre de mes inválido.");
        }
        
        validarFecha(m, dia, anio);
    }

    public Fecha(int diaDelAnio, int anio) {
        if (diaDelAnio < 1 || diaDelAnio > 366) {
            throw new IllegalArgumentException("Día del año (DDD) inválido.");
        }
        
        validarFecha(1, 1, anio);
        
        int diasRestantes = diaDelAnio;
        int m = 1;
        
        while (diasRestantes > 0) {
            int diasEnMes = DIAS_POR_MES[m];
            if (m == 2 && esBisiesto(anio)) {
                diasEnMes = 29;
            }
            
            if (diasRestantes <= diasEnMes) {
                this.mes = m;
                this.dia = diasRestantes;
                return;
            }
        
            diasRestantes -= diasEnMes;
            m++;
        }
    }

    public String aFormato1() {
        return String.format("%02d/%02d/%d", mes, dia, anio);
    }

    public String aFormato2() {
        String nombreMes = NOMBRES_MESES.get(mes - 1);
        nombreMes = nombreMes.substring(0, 1) + nombreMes.substring(1).toLowerCase();
        return String.format("%s %d, %d", nombreMes, dia, anio);
    }

    public String aFormato3() {
        int diaDelAnio = 0;
        for (int m = 1; m < this.mes; m++) {
            diaDelAnio += DIAS_POR_MES[m];
            if (m == 2 && esBisiesto(this.anio)) {
                diaDelAnio += 1;
            }
        }
        diaDelAnio += this.dia; // Sumar los días del mes actual
        return String.format("%03d %d", diaDelAnio, anio);
    }

    // Se mantiene toString para impresión general
    @Override
    public String toString() {
        return aFormato2(); 
    }
}