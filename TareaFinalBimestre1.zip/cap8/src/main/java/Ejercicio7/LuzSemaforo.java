package Ejercicio7;

public enum LuzSemaforo {
    ROJO( 30 ),
    VERDE( 35 ),
    AMARILLO( 5 );

    private final int duracion;

    LuzSemaforo( int duracionLuz ) {
        this.duracion = duracionLuz;
    }

    public int obtenerDuracion() {
        return duracion;
    }
}
