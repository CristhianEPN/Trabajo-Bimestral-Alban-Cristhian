package Ejercicio7;

public class PruebaLuzSemaforo {
    public static void main( String[] args ) {
        System.out.println("--- Constantes del Semaforo y sus Duraciones ---");
        System.out.printf("%-10s%-10s%n", "CONSTANTE", "DURACION (s)");
        System.out.println("--------------------");

        for ( LuzSemaforo luz : LuzSemaforo.values() ) {
            System.out.printf("%-10s%-10d%n", luz, luz.obtenerDuracion() );
        }
    }
}