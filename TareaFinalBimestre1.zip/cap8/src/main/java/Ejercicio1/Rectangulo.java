package Ejercicio1;

public class Rectangulo {
    private double longitud = 1.0;
    private double anchura = 1.0;

    // Constructor sin argumentos
    public Rectangulo() {
   
    }

    // Constructor con argumentos
    public Rectangulo(double longitudInicial, double anchuraInicial) {
        establecerLongitud(longitudInicial);
        establecerAnchura(anchuraInicial);
    }

    public void establecerLongitud(double longitudPrueba) {
        if (longitudPrueba > 0.0 && longitudPrueba < 20.0) {
            this.longitud = longitudPrueba;
        } else {

            System.out.printf("ERROR: Longitud %.1f inválida. Se mantiene el valor actual de %.1f.%n",
                longitudPrueba, this.longitud);
        }
    }

    public void establecerAnchura(double anchuraPrueba) {
        if (anchuraPrueba > 0.0 && anchuraPrueba < 20.0) {
            this.anchura = anchuraPrueba;
        } else {
            System.out.printf("ERROR: Anchura %.1f inválida. Se mantiene el valor actual de %.1f.%n",
                anchuraPrueba, this.anchura);
        }
    }

    // Obtiene la longitud
    public double obtenerLongitud() {
        return longitud;
    }

    // Obtiene la anchura
    public double obtenerAnchura() {
        return anchura;
    }

    // --- Métodos de Cálculo ---

    public double calcularPerimetro() {
        return 2 * (longitud + anchura);
    }
    
    //Calcular area
    public double calcularArea() {
        return longitud * anchura;
    }
}