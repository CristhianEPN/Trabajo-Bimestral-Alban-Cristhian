package Ejercicio1;

public class PruebaRectangulo {
    public static void main(String[] args) {
        // 1. Crear un rectángulo usando el constructor predeterminado (1.0 x 1.0)
        Rectangulo r1 = new Rectangulo();
        System.out.println("--- Rectángulo (r1) ---");
        imprimirDatos(r1);

        // 2. Crear un rectángulo con valores válidos (5.5 x 10.0)
        Rectangulo r2 = new Rectangulo(5.5, 10.0);
        System.out.println("\n--- PRUEBA 2: Rectángulo Válido (r2) ---");
        imprimirDatos(r2);

    }

    // Método auxiliar para imprimir los datos de un rectángulo
    public static void imprimirDatos(Rectangulo r) {
        System.out.printf("Longitud: %.1f%n", r.obtenerLongitud());
        System.out.printf("Anchura: %.1f%n", r.obtenerAnchura());
        System.out.printf("Perímetro: %.1f%n", r.calcularPerimetro());
        System.out.printf("Área: %.1f%n", r.calcularArea());
    }
}