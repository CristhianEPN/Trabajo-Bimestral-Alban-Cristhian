package Ejercicio2;

public class PruebaTiempo2Mejorado {

    public static void main(String[] args) {
        System.out.println("--- PRUEBA DE MÉTODOS DE INCREMENTO ---");

        // a) Incrementar el minuto, de manera que cambie al siguiente minuto.
        tiemp22 t11 = new tiemp22(10, 30, 59); // 10:30:59
        System.out.println("\nCaso a) Incrementar el minuto:");
        imprimirTiempo(t11, "Inicial (10:30:59)");
        t11.tictac();
        imprimirTiempo(t11, "tictac (Debe ser 10:31:00)");

        // b) Incrementar la hora, de manera que cambie a la siguiente hora.
        tiemp22 t22 = new tiemp22(14, 59, 0); // 14:59:00
        System.out.println("\nCaso b) Incrementar la hora (con incrementarMinuto):");
        imprimirTiempo(t22, "Inicial (14:59:00)");
        t22.incrementarMinuto(); // Pasa de 14:59 a 15:00
        imprimirTiempo(t22, "incrementarMinuto (Debe ser 15:00:00)");

        // c) Incrementar el tiempo de manera que cambie al siguiente día.
        // Prueba 1: Usando tictac
        tiemp22 t33 = new tiemp22(23, 59, 59); // 11:59:59 PM
        System.out.println("\nCaso c) Cambiar al siguiente día (con tictac):");
        imprimirTiempo(t33, "Inicial (23:59:59 PM)");
        t33.tictac(); // Pasa a 00:00:00
        imprimirTiempo(t33, "tictac (Debe ser 00:00:00 AM)");
        System.out.printf("");

        // Prueba 2: Usando incrementarHora para saltar medianoche
        tiemp22 t44 = new tiemp22(23, 10, 0); // 23:10:00
        System.out.println("\nCaso c) Cambiar al siguiente día (con incrementarHora):");
        imprimirTiempo(t44, "Inicial (23:10:00)");
        t44.incrementarHora(); // 23:10:00 + 1 hora = 00:10:00
        imprimirTiempo(t44, "incrementarHora (Debe ser 00:10:00 AM)");
        System.out.printf("");
        
        Tiempo2 t1 = new Tiempo2();          
        Tiempo2 t2 = new Tiempo2(13, 27, 6); 
        Tiempo2 t3 = new Tiempo2(22);      
        Tiempo2 t4 = new Tiempo2(t2);  
        
        System.out.printf("");
        System.out.printf("");
        System.out.printf("");
        System.out.println("--- Tiempo 2 Original ---");

        System.out.println("--- PRUEBA 1 ---");
        imprimirDatos("t1 (Default)", t1);
        imprimirDatos("t2 (Completo)", t2);
        imprimirDatos("t3 (Solo Hora)", t3);
        imprimirDatos("t4 (Copia de t2)", t4);

        System.out.println("\n--- PRUEBA 2: Mutadores (Setters) ---");
        t3.establecerHora(15);
        t3.establecerMinuto(55);
        t3.establecerSegundo(40);
        imprimirDatos("t3 Modificado (15:55:40)", t3);
    }

    public static void imprimirDatos(String etiqueta, Tiempo2 t) {
        System.out.printf("%s:%n", etiqueta);
        System.out.printf("  Universal: %s%n", t.aStringUniversal());
        System.out.printf("  Estándar:  %s%n", t.toString());
        System.out.printf("  Getters:   %d:%d:%d%n", t.obtenerHora(), t.obtenerMinuto(), t.obtenerSegundo());
    }

    // Método auxiliar para imprimir los datos
    public static void imprimirTiempo(tiemp22 t, String etiqueta) {
    	System.out.printf("");
        System.out.printf("  %s:%n", etiqueta);
        System.out.printf("    Universal: %s%n", t.aStringUniversal());
        System.out.printf("    Estándar:  %s%n", t.toString());
        System.out.printf("");
    }
    
    
}