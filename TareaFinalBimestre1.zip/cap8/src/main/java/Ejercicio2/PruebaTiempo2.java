package Ejercicio2;

//El mismo programa que prueba la versión original de Tiempo2.
public class PruebaTiempo2 {
 public static void main(String[] args) {
     Tiempo2 t1 = new Tiempo2();          
     Tiempo2 t2 = new Tiempo2(13, 27, 6); 
     Tiempo2 t3 = new Tiempo2(22);      
     Tiempo2 t4 = new Tiempo2(t2);        

     System.out.println("--- PRUEBA 1 ---");
     imprimirDatos("t1 (Default)", t1);
     imprimirDatos("t2 (Completo)", t2);
     imprimirDatos("t3 (Solo Hora)", t3);
     imprimirDatos("t4 (Copia de t2)", t4);

     System.out.println("\n--- PRUEBA 2: Mutadores (Setters) ---");
     t3.establecerHora(15);
     t3.establecerMinuto(55);
     t3.establecerSegundo(40);
     imprimirDatos("t3 Modificado (15:55:40)", t3);
 }

 public static void imprimirDatos(String etiqueta, Tiempo2 t) {
     System.out.printf("%s:%n", etiqueta);
     System.out.printf("  Universal: %s%n", t.aStringUniversal());
     System.out.printf("  Estándar:  %s%n", t.toString());
     System.out.printf("  Getters:   %d:%d:%d%n", t.obtenerHora(), t.obtenerMinuto(), t.obtenerSegundo());
 }
}