package Ejercicio2;


//Implementa Tiempo2 usando una variable interna: segundosDesdeMedianoche.

public class Tiempo2 {

 private int segundosDesdeMedianoche;

 private static final int SEGUNDOS_EN_DIA = 86400;

 public Tiempo2() {
     this(0, 0, 0); 
 }

 public Tiempo2(int h) {
     this(h, 0, 0); 
 }

 public Tiempo2(int h, int m) {
     this(h, m, 0); 
 }


 public Tiempo2(int h, int m, int s) {
     establecerTiempo(h, m, s);
 }

 public Tiempo2(Tiempo2 tiempo) {
     this.segundosDesdeMedianoche = tiempo.segundosDesdeMedianoche;
 }

 public void establecerTiempo(int h, int m, int s) {
     int horaValida = (h >= 0 && h < 24) ? h : 0;
     int minutoValido = (m >= 0 && m < 60) ? m : 0;
     int segundoValido = (s >= 0 && s < 60) ? s : 0;
     segundosDesdeMedianoche = 
         horaValida * 3600 + minutoValido * 60 + segundoValido;
 }

 public void establecerHora(int h) {
     establecerTiempo(h, obtenerMinuto(), obtenerSegundo());
 }

 public void establecerMinuto(int m) {
     establecerTiempo(obtenerHora(), m, obtenerSegundo());
 }

 public void establecerSegundo(int s) {
     establecerTiempo(obtenerHora(), obtenerMinuto(), s);
 }
 public int obtenerHora() {
     return segundosDesdeMedianoche / 3600;
 }

 public int obtenerMinuto() {
     return (segundosDesdeMedianoche % 3600) / 60;
 }


 public int obtenerSegundo() {
     return segundosDesdeMedianoche % 60;
 }


 public String aStringUniversal() {
     return String.format("%02d:%02d:%02d", 
         obtenerHora(), obtenerMinuto(), obtenerSegundo());
 }

 public String toString() {
     int hora12 = (obtenerHora() == 0 || obtenerHora() == 12) ? 12 : obtenerHora() % 12;
     String ampm = (obtenerHora() < 12) ? "AM" : "PM";
     
     return String.format("%d:%02d:%02d %s",
         hora12, obtenerMinuto(), obtenerSegundo(), ampm);
 }
}