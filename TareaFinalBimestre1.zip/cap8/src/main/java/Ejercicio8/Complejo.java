package Ejercicio8;

public class Complejo {
    private double parteReal;
    private double parteImaginaria;

    // Constructor sin argumentos (valores predeterminados a 0.0)
    public Complejo() {
        this(0.0, 0.0);
    }

    // Constructor que permite inicializar al declararse
    public Complejo(double parteReal, double parteImaginaria) {
        this.parteReal = parteReal;
        this.parteImaginaria = parteImaginaria;
    }
    
    public Complejo sumar(Complejo otro) {
        double nuevaParteReal = this.parteReal + otro.parteReal;
        double nuevaParteImaginaria = this.parteImaginaria + otro.parteImaginaria;
        return new Complejo(nuevaParteReal, nuevaParteImaginaria);
    }

    public Complejo restar(Complejo otro) {
        double nuevaParteReal = this.parteReal - otro.parteReal;
        double nuevaParteImaginaria = this.parteImaginaria - otro.parteImaginaria;
        return new Complejo(nuevaParteReal, nuevaParteImaginaria);
    }

    @Override
    public String toString() {
        return String.format("(%.2f, %.2f)", parteReal, parteImaginaria);
    }
}