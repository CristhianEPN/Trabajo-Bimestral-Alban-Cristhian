package Ejercicio8;

public class PruebaComplejo {

    public static void main(String[] args) {
        Complejo c1 = new Complejo(2.5, 3.0);
        Complejo c2 = new Complejo(1.0, -1.5);
        Complejo c3 = new Complejo();

        System.out.println("--- NÚMEROS COMPLEJOS INICIALES ---");
        System.out.printf("C1 = %s%n", c1);
        System.out.printf("C2 = %s%n", c2);
        System.out.printf("C3 = %s%n", c3); // (0.00, 0.00)

        Complejo suma = c1.sumar(c2);
        System.out.println("\n--- PRUEBA DE SUMA ---");
        System.out.printf("%s + %s = %s%n", c1, c2, suma);

        Complejo suma2 = c2.sumar(c3);
        System.out.printf("%s + %s = %s%n", c2, c3, suma2);

        Complejo resta = c1.restar(c2);
        System.out.println("\n--- PRUEBA DE RESTA ---");
        System.out.printf("%s - %s = %s%n", c1, c2, resta);

        Complejo resta2 = c3.restar(c1);
        System.out.printf("%s - %s = %s%n", c3, c1, resta2);
    }
}