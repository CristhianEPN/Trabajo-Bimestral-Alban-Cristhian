package Ejemplo2;

//Fig. 8.8: Empleado.java
//Clase Empleado con referencias a otros objetos. (Parte I de 2).
public class Empleado
{
 private String primerNombre;
 private String apellidoPaterno;
 private Fecha fechaNacimiento;
 private Fecha fechaContratacion;

 // constructor para inicializar nombre, fecha de nacimiento y fecha de contratación
 public Empleado( String nombre, String apellido, Fecha fechaDeNacimiento,
     Fecha fechaDeContratacion )
 {
     primerNombre = nombre;
     apellidoPaterno = apellido;
     fechaNacimiento = fechaDeNacimiento;
     fechaContratacion = fechaDeContratacion;
 } // fin del constructor de Empleado

 // convierte Empleado a formato String
 public String toString()
 {
     return String.format( "%s, %s Contratado: %s Cumpleaños: %s",
         apellidoPaterno, primerNombre, fechaContratacion, fechaNacimiento );
 } // fin del metodo toString
} // fin de la clase Empleado