package Ejercicio3;

public class PruebaCuentaDeAhorros {
	
	private static double tasaInteresAnual = 0.0; 

    private double saldoAhorros;

    public static void main(String[] args) {
        // Crear dos instancias de CuentaDeAhorros
        CuentaDeAhorros ahorrador1 = new CuentaDeAhorros(2000.00);
        CuentaDeAhorros ahorrador2 = new CuentaDeAhorros(3000.00);

        // Establecer la tasa de interés anual al 4% para todos (Uso de método static)
        CuentaDeAhorros.modificarTasaInteres(0.04);
        System.out.printf("--- MES 1: Tasa establecida al %.2f%% ---%n", 
            CuentaDeAhorros.obtenerTasaInteresAnual() * 100);

        // Calcular el interés mensual y actualizar saldos
        ahorrador1.calcularInteresMensual();
        ahorrador2.calcularInteresMensual();

        // Imprimir los nuevos saldos
        imprimirSaldos("Después del Mes 1", ahorrador1, ahorrador2);

        // Establecer la tasa de interés anual al 5% para todos (Uso de método static)
        CuentaDeAhorros.modificarTasaInteres(0.05);
        System.out.printf("\n--- MES 2: Tasa establecida al %.2f%% ---%n", 
            CuentaDeAhorros.obtenerTasaInteresAnual() * 100);

        // Calcular el interés del siguiente mes y actualizar saldos
        ahorrador1.calcularInteresMensual();
        ahorrador2.calcularInteresMensual();

        // Imprimir los nuevos saldos
        imprimirSaldos("Después del Mes 2", ahorrador1, ahorrador2);
    }
    public static void imprimirSaldos(String etapa, CuentaDeAhorros a1, CuentaDeAhorros a2) {
        System.out.printf("%s:%n", etapa);
        System.out.printf("  Ahorrador 1 Saldo: $%,.2f%n", a1.obtenerSaldoAhorros());
        System.out.printf("  Ahorrador 2 Saldo: $%,.2f%n", a2.obtenerSaldoAhorros());
    }
}