package Ejercicio3;

public class CuentaDeAhorros {

    private static double tasaInteresAnual;
    private double saldoAhorros;
    private double nuevaTasa;

    // Constructor
    public CuentaDeAhorros(double saldoInicial) {
        this.saldoAhorros = saldoInicial;
    }

    public static void modificarTasaInteres(double nuevaTasa) {
        tasaInteresAnual = nuevaTasa;
    }

    public void calcularInteresMensual() {
        double interesMensual = saldoAhorros * tasaInteresAnual / 12.0;
        saldoAhorros += interesMensual;
    }

    // --- Getters ---

    // Obtiene el saldo actual
    public double obtenerSaldoAhorros() {
        return saldoAhorros;
    }

    // Obtiene la tasa anual (método static para acceder a tasaInteresAnual)
    public static double obtenerTasaInteresAnual() {
        return tasaInteresAnual;
    }
}