package Ejercicio5;

public class Tiempo2 {
    private int segundosDesdeMedianoche;
    private static final int SEGUNDOS_EN_DIA = 86400;
    public Tiempo2() { this(0, 0, 0); }
    public Tiempo2(int h) { this(h, 0, 0); }
    public Tiempo2(int h, int m) { this(h, m, 0); }
    public Tiempo2(int h, int m, int s) { establecerTiempo(h, m, s); }
    public Tiempo2(Tiempo2 tiempo) { this.segundosDesdeMedianoche = tiempo.segundosDesdeMedianoche; }

    public boolean establecerTiempo(int h, int m, int s) {
        if (h >= 0 && h < 24 && m >= 0 && m < 60 && s >= 0 && s < 60) {

            segundosDesdeMedianoche = h * 3600 + m * 60 + s;
            return true;
        } else {
            return false;
        }
    }

    public boolean establecerHora(int h) {
        if (h >= 0 && h < 24) {
            establecerTiempo(h, obtenerMinuto(), obtenerSegundo());
            return true;
        } else {
            return false;
        }
    }

    public boolean establecerMinuto(int m) {
        if (m >= 0 && m < 60) {
            establecerTiempo(obtenerHora(), m, obtenerSegundo());
            return true;
        } else {
            return false;
        }
    }

    public boolean establecerSegundo(int s) {
        if (s >= 0 && s < 60) {
            establecerTiempo(obtenerHora(), obtenerMinuto(), s);
            return true;
        } else {
            return false;
        }
    }
    public int obtenerHora() { return segundosDesdeMedianoche / 3600; }
    public int obtenerMinuto() { return (segundosDesdeMedianoche % 3600) / 60; }
    public int obtenerSegundo() { return segundosDesdeMedianoche % 60; }

    public String aStringUniversal() {
        return String.format("%02d:%02d:%02d", obtenerHora(), obtenerMinuto(), obtenerSegundo());
    }

    public String toString() {
        int hora12 = (obtenerHora() == 0 || obtenerHora() == 12) ? 12 : obtenerHora() % 12;
        String ampm = (obtenerHora() < 12) ? "AM" : "PM";
        
        return String.format("%d:%02d:%02d %s",
            hora12, obtenerMinuto(), obtenerSegundo(), ampm);
    }
}