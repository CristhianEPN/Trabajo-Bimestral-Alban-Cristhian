package Ejercicio5;

public class PruebaTiempo2Booleano {

    public static void main(String[] args) {
        Tiempo2 tiempo = new Tiempo2();
        imprimirDatos("Inicial", tiempo);
        System.out.println("\n--- 1. Prueba de establecerTiempo (Válido) ---");
        boolean exito = tiempo.establecerTiempo(17, 45, 30);
        manejarResultado("establecerTiempo(17, 45, 30)", exito);
        imprimirDatos("Después del éxito", tiempo);

        System.out.println("\n--- 2. Prueba de establecerTiempo (Inválido) ---");
        exito = tiempo.establecerTiempo(25, 60, -1);
        manejarResultado("establecerTiempo(25, 60, -1)", exito);
        imprimirDatos("Después del fracaso (Debe ser 17:45:30)", tiempo);
        System.out.println("\n--- 3. Pruebas Individuales (Válido) ---");
        
        exito = tiempo.establecerHora(23);
        manejarResultado("establecerHora(23)", exito);

        exito = tiempo.establecerMinuto(59);
        manejarResultado("establecerMinuto(59)", exito);

        exito = tiempo.establecerSegundo(58);
        manejarResultado("establecerSegundo(58)", exito);
        imprimirDatos("Después de individuales válidas", tiempo);
        System.out.println("\n--- 4. Pruebas Individuales (Inválido) ---");
        
        exito = tiempo.establecerHora(30);
        manejarResultado("establecerHora(30)", exito);

        exito = tiempo.establecerMinuto(-10);
        manejarResultado("establecerMinuto(-10)", exito);
        
        imprimirDatos("Después de individuales inválidas (Debe ser 23:59:58)", tiempo);
    }
    public static void manejarResultado(String metodo, boolean exito) {
        if (exito) {
            System.out.printf("Éxito: %s fue ejecutado correctamente.%n", metodo);
        } else {
            System.out.printf("ERROR: %s falló. Valor(es) no válido(s). El tiempo NO se modificó.%n", metodo);
        }
    }
    public static void imprimirDatos(String etiqueta, Tiempo2 t) {
        System.out.printf("  %s:%n", etiqueta);
        System.out.printf("    Universal: %s%n", t.aStringUniversal());
        System.out.printf("    Estándar:  %s%n", t.toString());
    }
}
