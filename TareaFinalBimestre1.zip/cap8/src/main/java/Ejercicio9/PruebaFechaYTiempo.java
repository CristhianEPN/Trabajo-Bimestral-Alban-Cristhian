package Ejercicio9;

public class PruebaFechaYTiempo {

    public static void main(String[] args) {

        int mes = 6, dia = 15, anio = 2025;
        int hora = 23, minuto = 30, segundo = 0;
        
        FechaYTiempo fyt = new FechaYTiempo(mes, dia, anio, hora, minuto, segundo);
        
        System.out.println("--- PRUEBA DE INCREMENTO DE HORA CRUZANDO MEDIANOCHE ---");
        System.out.printf("Fecha/Hora Inicial: %s%n", fyt.aStringEstandar()); // 15/6/2025 11:30:00 PM
        
        // 1. Incrementar la hora (3600 segundos = 1 hora)
        System.out.println("\nLlamando a incrementarHora()...");
        fyt.incrementarHora(); 

        System.out.println("Resultado de incrementarHora():");
        System.out.printf("Universal: %s%n", fyt.aStringUniversal());
        System.out.printf("Estándar:  %s%n", fyt.aStringEstandar());

        FechaYTiempo fyt2 = new FechaYTiempo(2, 28, 2024, 23, 59, 59);
        System.out.println("\n--- PRUEBA DE CRUCE EXACTO DE MEDIANOCHE (DÍA BISIESTO) ---");
        System.out.printf("Inicial (28/02/2024): %s%n", fyt2.aStringUniversal());
        fyt2.tictac();

        System.out.println("Resultado de tictac():");
        System.out.printf("Universal: %s%n", fyt2.aStringUniversal());
        fyt2.tictac();
        
        System.out.println("Resultado de 2do tictac():");
        System.out.printf("Universal: %s%n", fyt2.aStringUniversal());
    }
}