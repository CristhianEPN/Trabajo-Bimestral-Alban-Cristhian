package Ejercicio9;

import Ejercicio2.tiemp22;
import Ejercicio4.Fecha2;
public class FechaYTiempo {
    
    private Fecha2 fecha;
    private tiemp22 tiempo;
    public FechaYTiempo(int mes, int dia, int anio, int hora, int minuto, int segundo) {
        fecha = new Fecha2(mes, dia, anio);
        tiempo = new tiemp22(hora, minuto, segundo);
    }

    public void tictac() {
        tiempo.tictac();
        if (tiempo.obtenerHora() == 0 && tiempo.obtenerMinuto() == 0 && tiempo.obtenerSegundo() == 0) {
            fecha.siguienteDia();
        }
    }

    public void incrementarHora() {
        int diaInicial = fecha.obtenerDia(); 
        
        for (int i = 0; i < 3600; i++) {
            tictac();
        }

    }

    public String aStringUniversal() {
        return String.format("%s %s", fecha.toString(), tiempo.aStringUniversal());
    }

    public String aStringEstandar() {
        return String.format("%s %s", fecha.toString(), tiempo.toString());
    }
}