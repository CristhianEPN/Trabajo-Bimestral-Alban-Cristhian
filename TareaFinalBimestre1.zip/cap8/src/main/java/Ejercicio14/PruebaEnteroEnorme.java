package Ejercicio14;

public class PruebaEnteroEnorme {

    public static void main(String[] args) {
        
        EnteroEnorme n1 = new EnteroEnorme();
        EnteroEnorme n2 = new EnteroEnorme();
        EnteroEnorme n3;

        String s1 = "12345678901234567890"; 
        String s2 = "98765432109876543210"; 
        String s_cero = "0";

        n1.entrada(s1);
        n2.entrada(s2);
        
        System.out.println("--- 1. ENTRADA Y SALIDA ---");
        System.out.printf("N1: %s%n", n1);
        System.out.printf("N2: %s%n", n2);
        System.out.println("\n--- 2. PRUEBA DE SUMA ---");
        n3 = n1.sumar(n2);
        System.out.printf("%s + %s = %s%n", n1, n2, n3);
        System.out.println("\n--- 3. PRUEBA DE RESTA (N2 - N1) ---");
        n3 = n2.restar(n1);
        System.out.printf("%s - %s = %s%n", n2, n1, n3);
        System.out.println("\n--- 4. PRUEBA DE RESTA (N1 - N1) ---");
        n3 = n1.restar(n1);
        System.out.printf("%s - %s = %s%n", n1, n1, n3); 
        System.out.printf("¿Es cero el resultado? %b%n", n3.esCero());
        System.out.println("\n--- 5. PRUEBA DE COMPARACIÓN ---");
        System.out.printf("N1 (%s) vs N2 (%s):%n", n1, n2);
        System.out.printf("  N1 esIgualA N2: %b%n", n1.esIgualA(n2));
        System.out.printf("  N1 noEsIgualA N2: %b%n", n1.noEsIgualA(n2));
        System.out.printf("  N1 esMayorQue N2: %b%n", n1.esMayorQue(n2));
        System.out.printf("  N1 esMenorQue N2: %b%n", n1.esMenorQue(n2));
        System.out.printf("  N1 esMayorOIgualA N2: %b%n", n1.esMayorOIgualA(n2));
        System.out.printf("  N1 esMenorOIgualA N2: %b%n", n1.esMenorOIgualA(n2));
        System.out.printf("\nN1 (%s) vs N1 (%s):%n", n1, n1);
        System.out.printf("  N1 esIgualA N1: %b%n", n1.esIgualA(n1));
    }
}