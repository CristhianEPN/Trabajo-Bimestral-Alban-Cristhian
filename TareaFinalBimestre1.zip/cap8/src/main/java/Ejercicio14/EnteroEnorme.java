package Ejercicio14;

import java.util.Arrays;

public class EnteroEnorme {
    private static final int TAMANO = 40;
    private int[] digitos = new int[TAMANO]; 

    public EnteroEnorme() {
    }

    public void entrada(String numeroStr) {
        Arrays.fill(digitos, 0); 
        
        int len = numeroStr.length();
        if (len > TAMANO) {
            numeroStr = numeroStr.substring(len - TAMANO);
            len = TAMANO;
        }

        for (int i = 0; i < len; i++) {
            digitos[TAMANO - len + i] = Character.getNumericValue(numeroStr.charAt(i));
        }
    }

    public String salida() {
        StringBuilder sb = new StringBuilder();
        boolean ceroAñadido = false;

        for (int i = 0; i < TAMANO; i++) {
            if (digitos[i] != 0 || ceroAñadido) {
                sb.append(digitos[i]);
                ceroAñadido = true;
            }
        }
        
        return (sb.length() == 0) ? "0" : sb.toString();
    }

    public EnteroEnorme sumar(EnteroEnorme otro) {
        EnteroEnorme resultado = new EnteroEnorme();
        int acarreo = 0;
        for (int i = TAMANO - 1; i >= 0; i--) {
            int suma = this.digitos[i] + otro.digitos[i] + acarreo;
            resultado.digitos[i] = suma % 10;
            acarreo = suma / 10;
        }

        if (acarreo > 0) {
            System.err.println("ADVERTENCIA: Desbordamiento de suma.");
        }
        return resultado;
    }

    public EnteroEnorme restar(EnteroEnorme otro) {
        if (otro.esMayorQue(this)) {
            throw new ArithmeticException("Error: El sustraendo es mayor que el minuendo.");
        }
        
        EnteroEnorme resultado = new EnteroEnorme();
        int prestamo = 0; 
        for (int i = TAMANO - 1; i >= 0; i--) {
            int resta = this.digitos[i] - otro.digitos[i] - prestamo;
            
            if (resta < 0) {
                resta += 10;
                prestamo = 1;
            } else {
                prestamo = 0;
            }
            resultado.digitos[i] = resta;
        }
        return resultado;
    }

    private int compararCon(EnteroEnorme otro) {
        for (int i = 0; i < TAMANO; i++) {
            if (this.digitos[i] > otro.digitos[i]) {
                return 1;
            }
            if (this.digitos[i] < otro.digitos[i]) {
                return -1; 
            }
        }
        return 0;
    }


    public boolean esIgualA(EnteroEnorme otro) {
        return compararCon(otro) == 0;
    }

    public boolean noEsIgualA(EnteroEnorme otro) {
        return compararCon(otro) != 0;
    }

    public boolean esMayorQue(EnteroEnorme otro) {
        return compararCon(otro) == 1;
    }

    public boolean esMenorQue(EnteroEnorme otro) {
        return compararCon(otro) == -1;
    }

    public boolean esMayorOIgualA(EnteroEnorme otro) {
        int resultado = compararCon(otro);
        return resultado == 1 || resultado == 0;
    }

    public boolean esMenorOIgualA(EnteroEnorme otro) {
        int resultado = compararCon(otro);
        return resultado == -1 || resultado == 0;
    }

    public boolean esCero() {
        return compararCon(new EnteroEnorme()) == 0;
    }

    @Override
    public String toString() {
        return salida();
    }
}