package Ejercicio10;

public class RectanguloMejorada {
    private Punto[] esquinas = new Punto[4];
    private double longitud = 0.0;
    private double anchura = 0.0;
    public RectanguloMejorada(Punto p1, Punto p2, Punto p3, Punto p4) {
        establecer(p1, p2, p3, p4);
    }

    private double distancia(Punto pA, Punto pB) {
        double dx = pA.obtenerX() - pB.obtenerX();
        double dy = pA.obtenerY() - pB.obtenerY();
        return Math.sqrt(dx * dx + dy * dy);
    }
    
    private boolean esCoordenadaValida(Punto p) {
        return (p.obtenerX() >= 0.0 && p.obtenerX() <= 20.0 &&
                p.obtenerY() >= 0.0 && p.obtenerY() <= 20.0);
    }

    public boolean establecer(Punto p1, Punto p2, Punto p3, Punto p4) {
        if (!esCoordenadaValida(p1) || !esCoordenadaValida(p2) || 
            !esCoordenadaValida(p3) || !esCoordenadaValida(p4)) {
            System.err.println("ERROR: Una o más coordenadas están fuera del rango [0.0, 20.0].");
            return false;
        }
        
        double[] xCoords = {p1.obtenerX(), p2.obtenerX(), p3.obtenerX(), p4.obtenerX()};
        double[] yCoords = {p1.obtenerY(), p2.obtenerY(), p3.obtenerY(), p4.obtenerY()};
        long uniqueX = java.util.Arrays.stream(xCoords).distinct().count();
        long uniqueY = java.util.Arrays.stream(yCoords).distinct().count();
        
        if (uniqueX != 2 || uniqueY != 2) {
            System.err.println("ERROR: Las coordenadas proporcionadas no especifican un rectángulo alineado a los ejes.");
            return false;
        }

        this.esquinas[0] = p1;
        this.esquinas[1] = p2;
        this.esquinas[2] = p3;
        this.esquinas[3] = p4;

        double minX = java.util.Arrays.stream(xCoords).min().getAsDouble();
        double maxX = java.util.Arrays.stream(xCoords).max().getAsDouble();
        double minY = java.util.Arrays.stream(yCoords).min().getAsDouble();
        double maxY = java.util.Arrays.stream(yCoords).max().getAsDouble();
        
        double lado1 = maxX - minX;
        double lado2 = maxY - minY;

        this.longitud = Math.max(lado1, lado2);
        this.anchura = Math.min(lado1, lado2);
        
        if (this.longitud == 0.0 || this.anchura == 0.0) {
            System.err.println("ERROR: El rectángulo debe tener un área positiva.");
            this.longitud = 0.0;
            this.anchura = 0.0;
            return false;
        }

        System.out.println("Rectángulo establecido correctamente.");
        return true;
    }

    public double calcularLongitud() {
        return longitud;
    }

    public double calcularAnchura() {
        return anchura;
    }

    public double calcularPerimetro() {
        return 2 * (longitud + anchura);
    }

    public double calcularArea() {
        return longitud * anchura;
    }
    
    public boolean esCuadrado() {
        return Math.abs(longitud - anchura) < 0.0001;
    }
}