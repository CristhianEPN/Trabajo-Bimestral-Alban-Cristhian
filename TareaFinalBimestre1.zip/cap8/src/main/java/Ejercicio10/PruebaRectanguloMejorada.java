package Ejercicio10;

public class PruebaRectanguloMejorada {
    public static void main(String[] args) {
        Punto p1 = new Punto(2.0, 5.0);
        Punto p2 = new Punto(12.0, 5.0);
        Punto p3 = new Punto(12.0, 10.0);
        Punto p4 = new Punto(2.0, 10.0);
        
        System.out.println("--- PRUEBA 1: Rectángulo Válido (10x5) ---");
        RectanguloMejorada rect1 = new RectanguloMejorada(p1, p2, p3, p4);
        imprimirDatos(rect1);
        System.out.printf("¿Es cuadrado? %s%n", rect1.esCuadrado() ? "Sí" : "No");

        Punto p5 = new Punto(1.0, 1.0);
        Punto p6 = new Punto(6.0, 1.0);
        Punto p7 = new Punto(6.0, 6.0);
        Punto p8 = new Punto(1.0, 6.0);
        
        System.out.println("\n--- PRUEBA 2: Cuadrado Válido (5x5) ---");
        RectanguloMejorada rect2 = new RectanguloMejorada(p5, p6, p7, p8);
        imprimirDatos(rect2);
        System.out.printf("¿Es cuadrado? %s%n", rect2.esCuadrado() ? "Sí" : "No");
        Punto pInvalidRange = new Punto(21.0, 10.0);
        Punto pValid = new Punto(10.0, 10.0);
        
        System.out.println("\n--- PRUEBA 3: Coordenada fuera de rango ---");
        RectanguloMejorada rect3 = new RectanguloMejorada(pInvalidRange, pValid, pValid, pValid);
        Punto pA = new Punto(1.0, 1.0);
        Punto pB = new Punto(2.0, 1.0);
        Punto pC = new Punto(3.0, 3.0);
        Punto pD = new Punto(1.0, 3.0); 
        
        System.out.println("\n--- PRUEBA 4: No es un rectángulo (3 valores X) ---");
        RectanguloMejorada rect4 = new RectanguloMejorada(pA, pB, pC, pD);
    }

    public static void imprimirDatos(RectanguloMejorada r) {
        System.out.printf("Longitud: %.1f%n", r.calcularLongitud());
        System.out.printf("Anchura: %.1f%n", r.calcularAnchura());
        System.out.printf("Perímetro: %.1f%n", r.calcularPerimetro());
        System.out.printf("Área: %.1f%n", r.calcularArea());
    }
}