package Ejercicio15;

public class TresEnRaya {
    private static final int VACIO = 0;
    private static final int JUGADOR_X = 1;
    private static final int JUGADOR_O = 2;
    private static final int TAMANO = 3;
    private int[][] tablero;

    public TresEnRaya() {
        tablero = new int[TAMANO][TAMANO];
    }

    public boolean realizarMovimiento(int fila, int columna, int jugador) {
        if (fila < 0 || fila >= TAMANO || columna < 0 || columna >= TAMANO) {
            System.err.println("Movimiento inválido: Coordenadas fuera del tablero.");
            return false;
        }

        if (tablero[fila][columna] != VACIO) {
            System.err.println("Movimiento inválido: La celda ya está ocupada.");
            return false;
        }

        tablero[fila][columna] = jugador;
        return true;
    }

    public int verificarEstado() {
        for (int i = 1; i <= 2; i++) { 
            for (int j = 0; j < TAMANO; j++) {
                if (tablero[j][0] == i && tablero[j][1] == i && tablero[j][2] == i) return i;
                if (tablero[0][j] == i && tablero[1][j] == i && tablero[2][j] == i) return i;
            }

            if (tablero[0][0] == i && tablero[1][1] == i && tablero[2][2] == i) return i;
            if (tablero[0][2] == i && tablero[1][1] == i && tablero[2][0] == i) return i;
        }

        boolean tableroLleno = true;
        for (int i = 0; i < TAMANO; i++) {
            for (int j = 0; j < TAMANO; j++) {
                if (tablero[i][j] == VACIO) {
                    tableroLleno = false;
                    break;
                }
            }
        }
        
        if (tableroLleno) return 3; 
        
        return 0; 
    }

    public void imprimirTablero() {
        System.out.println("  0 1 2");
        for (int i = 0; i < TAMANO; i++) {
            System.out.print(i + " ");
            for (int j = 0; j < TAMANO; j++) {
                char simbolo = ' ';
                if (tablero[i][j] == JUGADOR_X) simbolo = 'X';
                else if (tablero[i][j] == JUGADOR_O) simbolo = 'O';
                
                System.out.print(simbolo + (j == TAMANO - 1 ? "" : "|"));
            }
            System.out.println();
            if (i < TAMANO - 1) System.out.println("  -+-+-");
        }
        System.out.println();
    }
}