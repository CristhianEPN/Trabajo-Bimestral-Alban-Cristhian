package Ejercicio15;

import java.util.Scanner;

public class PruebaTresEnRaya {
    
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        TresEnRaya juego = new TresEnRaya();
        
        int jugadorActual = 1;
        int estado = 0;
        
        System.out.println("--- JUEGO TRES EN RAYA (Tic-Tac-Toe) ---");
        System.out.println("El jugador X (1) comienza.");
        juego.imprimirTablero();

        while (estado == 0) {
            String simbolo = (jugadorActual == 1) ? "X" : "O";
            System.out.printf("Turno del Jugador %s (%d). Ingrese fila y columna (ej: 0 1): ", simbolo, jugadorActual);
            
            if (!entrada.hasNextInt()) {
                System.err.println("Entrada inválida. Ingrese dos números.");
                entrada.nextLine(); 
                continue;
            }
            
            int fila = entrada.nextInt();
            int columna = entrada.nextInt();
            if (juego.realizarMovimiento(fila, columna, jugadorActual)) {
                juego.imprimirTablero();
                estado = juego.verificarEstado();
                if (estado == 0) {
                    jugadorActual = (jugadorActual == 1) ? 2 : 1;
                }
            } else {
            }
        }
       
        entrada.close();
        
        if (estado == 1 || estado == 2) {
            String ganador = (estado == 1) ? "X" : "O";
            System.out.printf("¡Felicidades! ¡El Jugador %s ha ganado el juego!%n", ganador);
        } else if (estado == 3) {
            System.out.println("¡Es un empate! El tablero está lleno.");
        }
    }
}