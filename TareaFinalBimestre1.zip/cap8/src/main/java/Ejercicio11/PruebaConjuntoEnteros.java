package Ejercicio11;

public class PruebaConjuntoEnteros {
    
    public static void main(String[] args) {
        ConjuntoEnteros c1 = new ConjuntoEnteros();
        ConjuntoEnteros c2 = new ConjuntoEnteros();
        c1.insertarElemento(10);
        c1.insertarElemento(20);
        c1.insertarElemento(30);
        c1.insertarElemento(40);

        c2.insertarElemento(30);
        c2.insertarElemento(40);
        c2.insertarElemento(50);
        c2.insertarElemento(60);
        
        System.out.println("--- 1. INICIALIZACIÓN Y ESTADO ---");
        System.out.printf("C1: %s%n", c1.toString()); 
        System.out.printf("C2: %s%n", c2.toString());
        
        ConjuntoEnteros cVacio = new ConjuntoEnteros();
        System.out.printf("Conjunto Vacío: %s%n", cVacio.toString());

        ConjuntoEnteros cUnion = c1.union(c2); // 10 20 30 40 50 60
        System.out.println("\n--- 2. UNIÓN (C1 U C2) ---");
        System.out.printf("Unión: %s%n", cUnion.toString());

        ConjuntoEnteros cInterseccion = c1.interseccion(c2); // 30 40
        System.out.println("\n--- 3. INTERSECCIÓN (C1 n C2) ---");
        System.out.printf("Intersección: %s%n", cInterseccion.toString());

        System.out.println("\n--- 4. ELIMINACIÓN Y MODIFICACIÓN ---");
        System.out.printf("C1 antes de eliminar 20: %s%n", c1.toString());
        c1.eliminarElemento(20);
        System.out.printf("C1 después de eliminar 20: %s%n", c1.toString()); // 10 30 40
        
        c1.insertarElemento(101);
        System.out.println("\n--- 5. COMPARACIÓN ---");
        
        ConjuntoEnteros cIgual = new ConjuntoEnteros();
        cIgual.insertarElemento(10);
        cIgual.insertarElemento(30);
        cIgual.insertarElemento(40);
        
        System.out.printf("C1: %s%n", c1.toString());
        System.out.printf("C_Igual: %s%n", cIgual.toString());
        System.out.printf("¿C1 es igual a C_Igual? %s%n", c1.esIgualA(cIgual));
        System.out.printf("¿C1 es igual a C2? %s%n", c1.esIgualA(c2));
        ConjuntoEnteros c3 = new ConjuntoEnteros();
        c3.insertarElemento(5);
        c3.eliminarElemento(5);
        System.out.println("\n--- 6. PRUEBA DE CONJUNTO VACÍO ---");
        System.out.printf("C3 después de eliminar 5: %s%n", c3.toString()); // ---
    }
}