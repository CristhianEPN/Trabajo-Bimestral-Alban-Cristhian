package Ejercicio11;

public class ConjuntoEnteros {
    private static final int TAMANO_CONJUNTO = 101;
    private boolean[] conjunto;
    public ConjuntoEnteros() {
        conjunto = new boolean[TAMANO_CONJUNTO]; 
    }

    public ConjuntoEnteros union(ConjuntoEnteros otro) {
        ConjuntoEnteros resultado = new ConjuntoEnteros();
        
        for (int i = 0; i < TAMANO_CONJUNTO; i++) {
            if (this.conjunto[i] || otro.conjunto[i]) {
                resultado.conjunto[i] = true;
            }
        }
        return resultado;
    }

    public ConjuntoEnteros interseccion(ConjuntoEnteros otro) {
        ConjuntoEnteros resultado = new ConjuntoEnteros();
        
        for (int i = 0; i < TAMANO_CONJUNTO; i++) {
            if (this.conjunto[i] && otro.conjunto[i]) {
                resultado.conjunto[i] = true;
            }
        }
        return resultado;
    }

    public void insertarElemento(int k) {
        if (k >= 0 && k < TAMANO_CONJUNTO) {
            conjunto[k] = true;
        } else {
            System.err.printf("Advertencia: %d fuera del rango [0, 100] para inserción.%n", k);
        }
    }

    public void eliminarElemento(int m) {
        if (m >= 0 && m < TAMANO_CONJUNTO) {
            conjunto[m] = false;
        } else {
            System.err.printf("Advertencia: %d fuera del rango [0, 100] para eliminación.%n", m);
        }
    }

    public boolean esIgualA(ConjuntoEnteros otro) {
        for (int i = 0; i < TAMANO_CONJUNTO; i++) {
            if (this.conjunto[i] != otro.conjunto[i]) {
                return false;
            }
        }
        return true;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        boolean estaVacio = true;
        
        for (int i = 0; i < TAMANO_CONJUNTO; i++) {
            if (conjunto[i]) {
                sb.append(i).append(" ");
                estaVacio = false;
            }
        }
        
        if (estaVacio) {
            return "---";
        }
        return sb.toString().trim();
    }
}