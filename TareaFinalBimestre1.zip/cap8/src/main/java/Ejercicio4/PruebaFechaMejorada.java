package Ejercicio4;

public class PruebaFechaMejorada {

    public static void main(String[] args) {
    	Fecha2 fechaMes = new Fecha2(1, 31, 2024);
        probarIncremento(fechaMes, 5, "a) Prueba de Cambio de Mes (Enero 31 -> Febrero 1)");
        Fecha2 fechaAnio = new Fecha2(12, 31, 2024); 
        probarIncremento(fechaAnio, 5, "b) Prueba de Cambio de Año (Diciembre 31 -> Enero 1)");
        Fecha2 fechaBisiesto = new Fecha2(2, 28, 2024);
        probarIncremento(fechaBisiesto, 5, "c) Prueba de Año Bisiesto (Febrero 28)");
    }
    public static void probarIncremento(Fecha2 fecha, int iteraciones, String titulo) {
        System.out.printf("\n--- %s ---%n", titulo);
        System.out.printf("Fecha Inicial: %s%n", fecha);

        for (int i = 0; i < iteraciones; i++) {
            fecha.siguienteDia();
            System.out.printf("  Día %d: %s%n", i + 1, fecha);
        }
    }
}