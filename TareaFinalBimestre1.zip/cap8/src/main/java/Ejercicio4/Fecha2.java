package Ejercicio4;

public class Fecha2 {
    private int mes;
    private int dia;
    private int anio;

    // --- Constructor ---
    public Fecha2(int elMes, int elDia, int elAnio) {
        this.anio = comprobarAnio(elAnio);
        this.mes = comprobarMes(elMes);
        this.dia = comprobarDia(elDia); 

        System.out.printf(
            "Constructor de objeto Fecha para la fecha %s%n", this);
    } 

    private int comprobarAnio(int anioPrueba) {
        if (anioPrueba >= 1900 && anioPrueba <= 2100) {
            return anioPrueba;
        } else {
            System.out.printf(
                "ADVERTENCIA: Año inválido (%d) se estableció en 1900.%n", anioPrueba);
            return 1900;
        }
    }
    private int comprobarMes(int mesPrueba) {
        if (mesPrueba > 0 && mesPrueba <= 12) {
            return mesPrueba;
        } else {
            System.out.printf(
                "ADVERTENCIA: Mes inválido (%d) se estableció en 1.%n", mesPrueba);
            return 1;
        }
    }
    private int comprobarDia(int diaPrueba) {
        int diasPorMes[] =
            { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

        if (diaPrueba > 0 && diaPrueba <= diasPorMes[mes]) {
            return diaPrueba;
        }

        if (mes == 2 && diaPrueba == 29 && (anio % 400 == 0 || 
             (anio % 4 == 0 && anio % 100 != 0))) {
            return diaPrueba;
        }

        System.out.printf("ADVERTENCIA: Día inválido (%d) se estableció en 1.%n", diaPrueba);
        return 1; 
    }

    public void siguienteDia() {
        int diaSiguiente = comprobarDia(dia + 1);

        if (diaSiguiente > dia) {
            dia = diaSiguiente;
        } else {

            dia = 1;

            if (mes < 12) {
                mes++;
            } else {
                mes = 1;
                anio++;
            }
        }
    }
    public int obtenerMes() { return mes; }
    public int obtenerDia() { return dia; }
    public int obtenerAnio() { return anio; }
    public String toString() {
        return String.format("%d/%d/%d", mes, dia, anio);
    }
}