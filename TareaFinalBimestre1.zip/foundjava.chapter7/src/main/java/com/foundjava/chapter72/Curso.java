package com.foundjava.chapter72;

import java.util.ArrayList;

import java.util.List;


// Clase Curso
class Curso {
    private String nombre;
    private int duracion; // en horas
    private double precio;
    
    public Curso(String nombre, int duracion, double precio) {
        this.nombre = nombre;
        this.duracion = duracion;
        this.precio = precio;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public int getDuracion() {
        return duracion;
    }
    
    public double getPrecio() {
        return precio;
    }
    
    @Override
    public String toString() {
        return String.format("Curso: %s | Duración: %d hrs | Precio: $%.2f", 
                           nombre, duracion, precio);
    }
    
 // Clase de prueba
	public static void main(String[] args) {
        System.out.println("----------------------------------------\n");
        System.out.println("     EJERCICIO 7.2 - CLASE PROSPECTO");
        
        // Crear cursos
        Curso java = new Curso("Programación en Java", 40, 299.99);
        Curso python = new Curso("Python para Principiantes", 30, 249.99);
        Curso web = new Curso("Desarrollo Web Full Stack", 60, 399.99);
        Curso bd = new Curso("Bases de Datos MySQL", 25, 199.99);
        Curso react = new Curso("React y Redux", 35, 279.99);
        
        // Crear prospecto
        Prospecto prospecto1 = new Prospecto(
            "María García", 
            "maria.garcia@email.com", 
            "+593-99-123-4567"
        );
        
        System.out.println("--- Agregando cursos individualmente ---");
        prospecto1.agregarCurso(java);
        prospecto1.agregarCurso(python);
        
        System.out.println("\n--- Agregando múltiples cursos ---");
        prospecto1.agregarCursos(web, bd, react);
        
        prospecto1.verCursos();
        
        System.out.println("\n" + "=".repeat(45));
        
        // Segundo prospecto
        Prospecto prospecto2 = new Prospecto(
            "Carlos Mendoza",
            "carlos.m@email.com",
            "+593-98-765-4321"
        );
        
        System.out.println("\n--- Nuevo Prospecto ---");
        prospecto2.agregarCursos(java, react);
        prospecto2.verCursos();
      
    }
}

