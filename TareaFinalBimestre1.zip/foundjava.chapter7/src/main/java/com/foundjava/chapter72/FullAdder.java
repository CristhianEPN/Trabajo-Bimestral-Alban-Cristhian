package com.foundjava.chapter72;

public class FullAdder {

    private HalfAdder ha1 = new HalfAdder();
    private HalfAdder ha2 = new HalfAdder();
    private OrGate orGate = new OrGate();

    private int sum;
    private int carryOut;

    public void setInput(int a, int b, int carryIn) {

        // Primer half adder: suma A + B
        ha1.setInput(a, b);

        // Segundo half adder: suma el resultado con el carry de entrada
        ha2.setInput(ha1.getResult(), carryIn);

        // La suma final es la suma del segundo half adder
        sum = ha2.getResult();

        // El carry final es OR entre los carries de cada half adder
        carryOut = orGate.getOutput(ha1.getCarry(), ha2.getCarry());
    }

    public int getSum() {
        return sum;
    }

    public int getCarryOut() {
        return carryOut;
    }
}
