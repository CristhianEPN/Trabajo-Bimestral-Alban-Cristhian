package com.foundjava.chapter72;

public class AndGate {

    public int getOutput(int input1, int input2) {
        if (input1 == 1 && input2 == 1) {
            return 1;
        } else {
            return 0;
        }
    }
}
