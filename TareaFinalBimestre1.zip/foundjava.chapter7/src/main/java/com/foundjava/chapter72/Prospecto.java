package com.foundjava.chapter72;

import java.util.ArrayList;

import java.util.List;

public class Prospecto {
	 private String nombre;
	    private String email;
	    private String telefono;
	    private List<Curso> cursosInscritos;
	    
	    public Prospecto(String nombre, String email, String telefono) {
	        this.nombre = nombre;
	        this.email = email;
	        this.telefono = telefono;
	        this.cursosInscritos = new ArrayList<>();
	    }
	    
	    // Método para agregar un curso
	    public void agregarCurso(Curso curso) {
	        cursosInscritos.add(curso);
	        System.out.println("✓ Curso agregado: " + curso.getNombre());
	    }
	    
	    // Método para agregar múltiples cursos
	    public void agregarCursos(Curso... cursos) {
	        for (Curso curso : cursos) {
	            agregarCurso(curso);
	        }
	    }
	    
	 // Método para ver los cursos inscritos
	    public void verCursos() {
	        if (cursosInscritos.isEmpty()) {
	            System.out.println("No hay cursos inscritos.");
	            return;
	        }
	        
	        System.out.println("\n=== Cursos de " + nombre + " ===");
	        for (int i = 0; i < cursosInscritos.size(); i++) {
	            System.out.println((i + 1) + ". " + cursosInscritos.get(i));
	        }
	    }
	    
	    // Método para calcular el costo total
	    public double calcularCostoTotal() {
	        double total = 0;
	        for (Curso curso : cursosInscritos) {
	            total += curso.getPrecio();
	        }
	        return total;
	    }
	    
	    // Método para calcular las horas totales
	    public int calcularHorasTotales() {
	        int total = 0;
	        for (Curso curso : cursosInscritos) {
	            total += curso.getDuracion();
	        }
	        return total;
	    }
	    
	    // Método para obtener la cantidad de cursos
	    public int getCantidadCursos() {
	        return cursosInscritos.size();
	    }
	    
	    public String getNombre() {
	        return nombre;
	    }
	    
	    public String getEmail() {
	        return email;
	    }
	    
	    public String getTelefono() {
	        return telefono;
	    }
	    
	    
}

