package com.foundjava.chapter72;

public class FourBitAdder {

    private FullAdder fa0 = new FullAdder(); // bit 0 (LSB)
    private FullAdder fa1 = new FullAdder(); // bit 1
    private FullAdder fa2 = new FullAdder(); // bit 2
    private FullAdder fa3 = new FullAdder(); // bit 3 (MSB)

    private int[] sum = new int[4];
    private int carryOut;

    public void add(int[] A, int[] B) {
        int carry = 0;

        // Bit 0
        fa0.setInput(A[0], B[0], carry);
        sum[0] = fa0.getSum();
        carry = fa0.getCarryOut();

        // Bit 1
        fa1.setInput(A[1], B[1], carry);
        sum[1] = fa1.getSum();
        carry = fa1.getCarryOut();

        // Bit 2
        fa2.setInput(A[2], B[2], carry);
        sum[2] = fa2.getSum();
        carry = fa2.getCarryOut();

        // Bit 3
        fa3.setInput(A[3], B[3], carry);
        sum[3] = fa3.getSum();
        carryOut = fa3.getCarryOut();
    }

    public int[] getSum() {
        return sum;
    }

    public int getCarryOut() {
        return carryOut;
    }
}

