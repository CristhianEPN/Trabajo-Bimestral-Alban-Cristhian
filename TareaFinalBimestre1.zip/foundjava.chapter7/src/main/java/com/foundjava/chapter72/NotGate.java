package com.foundjava.chapter72;

public class NotGate {

    public int getOutput(int input) {
        if (input == 0) {
            return 1;
        } else {
            return 0;
        }
    }
}
