package com.foundjava.chapter72;

public class PruebaAdder {
    public static void main(String[] args) {

        FourBitAdder adder = new FourBitAdder();

        int[] A = {1, 0, 1, 1}; // 1101 = 13
        int[] B = {1, 1, 0, 0}; // 0011 = 3

        adder.add(A, B);

        int[] result = adder.getSum();

        System.out.println("Resultado (4 bits): "
            + result[3] + " "
            + result[2] + " "
            + result[1] + " "
            + result[0]);

        System.out.println("Carry final: " + adder.getCarryOut());
    }

}
