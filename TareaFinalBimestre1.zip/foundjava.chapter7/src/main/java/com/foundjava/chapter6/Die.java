package com.foundjava.chapter6;


public class Die {
    // Number of sides on the die
    private static final int SIDES = 6;
    
    /**
     * Default constructor for Die
     */
    public Die() {
        // Constructor vacío, el dado no necesita inicialización especial
    }
    
    /**
     * Rolls the die and returns a random number between 1 and 6
     * @return a random integer between 1 and 6 (inclusive)
     */
    public int roll() {
        return (int)(Math.random() * SIDES) + 1;
    }
    
    /**
     * Returns the number of sides on this die
     * @return the number of sides (6)
     */
    public int getSides() {
        return SIDES;
    }
    
    /**
     * Test method to verify the die works correctly
     */
    public static void main(String[] args) {
        Die testDie = new Die();
        System.out.println("Testing Die class:");
        System.out.println("Rolling the die 10 times:");
        
        for (int i = 1; i <= 10; i++) {
            int result = testDie.roll();
            System.out.println("Roll " + i + ": " + result);
        }
    }
}