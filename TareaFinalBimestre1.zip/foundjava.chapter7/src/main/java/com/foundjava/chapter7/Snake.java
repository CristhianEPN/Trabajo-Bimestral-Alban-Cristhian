package com.foundjava.chapter7;

class Snake extends Mover {
    
    Snake(BoardSquare head, BoardSquare tail) {
        super(tail); // tail is the destination
        head.addMover(this);
    }
    
    @Override
    void showMessage() {
        System.out.println("  🐍 Down the snake to square " + 
            getDestination().getPosition());
    }
}