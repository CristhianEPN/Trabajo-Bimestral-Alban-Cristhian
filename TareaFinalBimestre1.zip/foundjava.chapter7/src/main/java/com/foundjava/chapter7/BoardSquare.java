package com.foundjava.chapter7;

class BoardSquare {
    private Mover aMover = null;
    private int position;
    
    BoardSquare(int position) {
        setPosition(position);
    }
    
    int getPosition() {
        return position;
    }
    
    private void setPosition(int position) {
        this.position = position;
    }
    
    // Add a Mover (can be Snake or Ladder) to this square
    void addMover(Mover mover) {
        this.aMover = mover;
    }
    
    // Check if this square has a Mover
    private boolean hasMover() {
        return aMover != null;
    }
    
    // Move the player piece using polymorphism
    public void movePlayerPiece(PlayerPiece counter) {
        counter.setCurrentPosition(this);
        
        // If there's a Mover on this square, use its polymorphic method
        if (hasMover()) {
            aMover.movePlayerPiece(counter);
        }
    }
}
