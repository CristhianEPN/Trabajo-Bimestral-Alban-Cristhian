package com.foundjava.chapter7;

class Ladder extends Mover {
    
    Ladder(BoardSquare top, BoardSquare foot) {
        super(top); // top is the destination
        foot.addMover(this);
    }
    
    @Override
    void showMessage() {
        System.out.println("  🪜 Up the ladder to square " + 
            getDestination().getPosition());
    }
}
