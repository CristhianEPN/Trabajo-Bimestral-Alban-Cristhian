package com.foundjava.chapter7;

public class SnakesAndLadders {
    // reference to the GameBoard
    private GameBoard board;
    
    // the constructor creates the Board
    public SnakesAndLadders() {
        board = new GameBoard();
    }
    
    // this method acts as a controller for playing the game with TWO players
    public void play() {
        // Create two players
        PlayerPiece player1 = new PlayerPiece("Red");
        PlayerPiece player2 = new PlayerPiece("Blue");
        
        // Set both players at the start
        player1.setCurrentPosition(board.getStartSquare());
        player2.setCurrentPosition(board.getStartSquare());
        
        System.out.println("========================================");
        System.out.println("   SNAKES AND LADDERS - TWO PLAYERS");
        System.out.println("   (Using Polymorphism with Mover)");
        System.out.println("========================================");
        System.out.println("Players: Red vs Blue");
        System.out.println("First to reach square 100 wins!");
        System.out.println("========================================\n");
        
        int turnCount = 0;
        PlayerPiece winner = null;
        
        // Game loop - alternate turns until someone wins
        while (!player1.hasFinished() && !player2.hasFinished()) {
            turnCount++;
            System.out.println("--- Turn " + turnCount + " ---");
            
            // Player 1's turn
            if (!player1.hasFinished()) {
                boolean player1Wins = board.movePlayerPiece(player1);
                if (player1Wins) {
                    winner = player1;
                    break;
                }
            }
            
            System.out.println();
            
            // Player 2's turn
            if (!player2.hasFinished()) {
                boolean player2Wins = board.movePlayerPiece(player2);
                if (player2Wins) {
                    winner = player2;
                    break;
                }
            }
            
            System.out.println();
        }
        
        // Announce the winner
        System.out.println("========================================");
        System.out.println("           GAME OVER!");
        System.out.println("========================================");
        if (winner != null) {
            System.out.println("🏆 " + winner.getColor() + " WINS! 🏆");
            System.out.println("\n" + winner.getColor() + " reached square 100 first!");
            
            // Show final positions
            PlayerPiece loser = (winner == player1) ? player2 : player1;
            System.out.println("\nFinal Positions:");
            System.out.println("  " + winner.getColor() + ": Square 100 (WINNER!)");
            System.out.println("  " + loser.getColor() + ": Square " + 
                loser.getCurrentPosition().getPosition());
        }
        System.out.println("\nTotal turns: " + turnCount);
        System.out.println("========================================");
    }
    
    // 'main' creates a 'SnakesAndLadders' object and
    // starts the game
    public static void main(String[] args) {
        SnakesAndLadders myGame = new SnakesAndLadders();
        myGame.play();
    }
}