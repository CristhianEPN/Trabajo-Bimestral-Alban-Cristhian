package com.foundjava.chapter7;

public class Die {
    private static final int SIDES = 6;
    
    public int roll() {
        return (int)(Math.random() * SIDES) + 1;
    }
}