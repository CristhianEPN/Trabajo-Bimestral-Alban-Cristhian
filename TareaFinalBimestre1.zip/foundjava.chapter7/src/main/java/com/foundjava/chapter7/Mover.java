package com.foundjava.chapter7;

abstract class Mover {
private BoardSquare destination;

	// Constructor
	Mover(BoardSquare destination) {
	    this.destination = destination;
	}
	
	// Getter for destination
	protected BoardSquare getDestination() {
	    return destination;
	}
	
	// Setter for destination
	protected void setDestination(BoardSquare destination) {
	    this.destination = destination;
	}
	
	// Polymorphic method that must be implemented by subclasses
	abstract void showMessage();
	
	// Common method to move the player piece
	void movePlayerPiece(PlayerPiece counter) {
	    showMessage();
	    counter.setCurrentPosition(getDestination());
	}
}
