package com.foundjava.chapter7;

class PlayerPiece {
    private String color;
    private BoardSquare currentPosition;
    private boolean hasFinished;
    
    PlayerPiece(String color) {
        this.color = color;
        this.hasFinished = false;
    }
    
    String getColor() {
        return color;
    }
    
    BoardSquare getCurrentPosition() {
        return currentPosition;
    }
    
    void setCurrentPosition(BoardSquare position) {
        this.currentPosition = position;
    }
    
    void moveTo(BoardSquare newPosition) {
        newPosition.movePlayerPiece(this);
    }
    
    boolean hasFinished() {
        return hasFinished;
    }
    
    void setFinished(boolean finished) {
        this.hasFinished = finished;
    }
}