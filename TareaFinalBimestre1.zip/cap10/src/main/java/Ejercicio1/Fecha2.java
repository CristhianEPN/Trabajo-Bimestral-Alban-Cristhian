package Ejercicio1;

public class Fecha2 {
    private int mes; 
    private int dia;  
    private int anio; 


    public Fecha2(int elMes, int elDia, int elAnio) {
        this.mes = elMes;
        this.dia = elDia;
        this.anio = elAnio;
    } 

    public int obtenerMes() { return mes; }
    public int obtenerDia() { return dia; }
    public int obtenerAnio() { return anio; }

    @Override
    public String toString() {
        return String.format("%d/%d/%d", mes, dia, anio);
    }
   
    public boolean esMesCumpleanios(int mesActual) {
        return this.mes == mesActual;
    }
}