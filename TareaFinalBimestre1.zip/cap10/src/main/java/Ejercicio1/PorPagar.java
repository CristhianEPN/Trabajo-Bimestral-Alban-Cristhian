package Ejercicio1;

public interface PorPagar {

}
