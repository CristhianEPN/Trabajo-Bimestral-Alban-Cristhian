package Ejercicio1;

import Deitel.cap10.PorPagar;
public abstract class Empleado2 implements PorPagar {
    
    private String primerNombre;
    private String apellidoPaterno;
    private String numeroSeguroSocial;
    private Fecha2 fechaNacimiento; 

    public Empleado2( String nombre, String apellido, String nss, Fecha2 fechaNac )
    {
        primerNombre = nombre;
        apellidoPaterno = apellido;
        numeroSeguroSocial = nss;
        fechaNacimiento = fechaNac; 
    } 

    public String obtenerPrimerNombre() {
        return primerNombre;
    }
    
    public String obtenerApellidoPaterno() {
        return apellidoPaterno;
    }

    public String obtenerNumeroSeguroSocial() {
        return numeroSeguroSocial;
    }
    
    public Fecha2 obtenerFechaNacimiento() {
        return fechaNacimiento;
    }
    
    @Override
    public String toString()
    {
        return String.format( "%s %s\nnumero de seguro social: %s\nfecha de nacimiento: %s",
            primerNombre, apellidoPaterno, numeroSeguroSocial, fechaNacimiento );
    } 

    public abstract double obtenerMontoPago();
}