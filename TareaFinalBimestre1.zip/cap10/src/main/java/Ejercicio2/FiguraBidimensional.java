package Ejercicio2;

public abstract class FiguraBidimensional extends Figura {
    public abstract double obtenerArea();
}