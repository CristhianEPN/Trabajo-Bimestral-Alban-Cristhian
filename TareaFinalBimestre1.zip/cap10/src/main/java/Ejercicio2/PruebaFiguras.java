package Ejercicio2;

public class PruebaFiguras {

    public static void main(String[] args) {
        Figura figuras[] = new Figura[4];
        figuras[0] = new Circulo(5.0);
        figuras[1] = new Cubo(4.0); 
        figuras[2] = new Circulo(1.5);
        figuras[3] = new Cubo(10.0);

        System.out.println("--- PROCESAMIENTO POLIMÓRFICO DE FIGURAS ---");
        System.out.println("----------------------------------------------");
        for (Figura figuraActual : figuras) {
            System.out.println(figuraActual);
            
            if (figuraActual instanceof FiguraBidimensional) {
                FiguraBidimensional figBidim = (FiguraBidimensional) figuraActual;
                
                System.out.printf("  Tipo: Bidimensional. Área: %.2f%n", figBidim.obtenerArea());
            } 
            else if (figuraActual instanceof FiguraTridimensional) {
                FiguraTridimensional figTridim = (FiguraTridimensional) figuraActual;
                
                System.out.printf("  Tipo: Tridimensional. Área Superficial: %.2f%n", figTridim.obtenerArea());
                System.out.printf("  Volumen: %.2f%n", figTridim.obtenerVolumen());
            }
            
            System.out.println("----------------------------------------------");
        }
    }
}