package Ejercicio2;

public abstract class FiguraTridimensional extends Figura {
    public abstract double obtenerArea();   
    public abstract double obtenerVolumen();
}