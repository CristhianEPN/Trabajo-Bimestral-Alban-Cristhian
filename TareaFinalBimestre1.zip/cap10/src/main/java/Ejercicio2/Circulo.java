package Ejercicio2;

public class Circulo extends FiguraBidimensional {
    private double radio;
    
    public Circulo(double r) {
        this.radio = r;
    }
    
    @Override
    public double obtenerArea() {
        return Math.PI * radio * radio;
    }
    
    @Override
    public String obtenerDescripcion() {
        return String.format("Círculo (Bidimensional) con radio %.2f", radio);
    }
}