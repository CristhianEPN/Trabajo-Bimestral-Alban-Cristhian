package Ejercicio2;

public abstract class Figura {
 public abstract String obtenerDescripcion();
 
 @Override
 public String toString() {
     return obtenerDescripcion();
 }
}