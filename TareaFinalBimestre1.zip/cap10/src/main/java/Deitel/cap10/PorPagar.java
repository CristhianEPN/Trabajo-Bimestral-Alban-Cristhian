package Deitel.cap10;

public interface PorPagar
{
    double obtenerMontoPago(); 
}