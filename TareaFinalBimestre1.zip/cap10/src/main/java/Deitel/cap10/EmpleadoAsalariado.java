package Deitel.cap10;

// Fig. 10.14: EmpleadoAsalariado.java
//La clase EmpleadoAsalariado extiende a Empleado, que implementa a PorPagar.
public class EmpleadoAsalariado extends Empleado
{
 private double salarioSemanal;

 // constructor de cuatro argumentos
 public EmpleadoAsalariado( String nombre, String apellido, String nss,
     double salario )
 {
     // Pasa argumentos al constructor de la superclase Empleado
     super( nombre, apellido, nss ); 
     establecerSalarioSemanal( salario ); 
 } // fin del constructor de EmpleadoAsalariado con cuatro argumentos

 // establece el salario
 public void establecerSalarioSemanal( double salario )
 {
     salarioSemanal = ( salario < 0.0 ) ? 0.0 : salario;
 } // fin del método establecerSalarioSemanal

 // devuelve el salario
 public double obtenerSalarioSemanal()
 {
     return salarioSemanal;
 } // fin del método obtenerSalarioSemanal

 // Implementa el método de la interfaz PorPagar (antes abstracto en Empleado)
 @Override
 public double obtenerMontoPago()
 {
     return obtenerSalarioSemanal();
 } // fin del método obtenerMontoPago

 // devuelve representación String de un objeto EmpleadoAsalariado
 @Override
 public String toString()
 {
     return String.format( "empleado asalariado: %s\n%s: $%,.2f",
         super.toString(), "salario semanal", obtenerSalarioSemanal() );
 } // fin de la clase EmpleadoAsalariado
} // fin de la clase EmpleadoAsalariado