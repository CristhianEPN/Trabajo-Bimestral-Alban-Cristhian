package Deitel.cap10;

//Fig. 10.8: EmpleadoBaseMasComision.java
//La clase EmpleadoBaseMasComision extiende a EmpleadoPorComision.
public class EmpleadoBaseMasComision extends EmpleadoPorComision
{
    private double salarioBase; // salario base por semana

    // constructor con seis argumentos
    public EmpleadoBaseMasComision( String nombre, String apellido, String nss,
        double ventas, double tarifa, double salario )
    {
        super( nombre, apellido, nss, ventas, tarifa ); // lo pasa al constructor de la superclase
        establecerSalarioBase( salario ); // valida y almacena el salario base
    } // fin del constructor de EmpleadoBaseMasComision con seis argumentos

    // establece el salario base
    public void establecerSalarioBase( double salario )
    {
        salarioBase = ( salario < 0.0 ) ? 0.0 : salario; // positivo
    } // fin del método establecerSalarioBase

    // devuelve el salario base
    public double obtenerSalarioBase()
    {
        return salarioBase;
    } // fin del método obtenerSalarioBase

    // calcula los ingresos; sobrescribe el método abstracto obtenerMontoPago en Empleado
    @Override // Línea 31
    public double obtenerMontoPago()
    {
        // La comisión se calcula llamando a obtenerMontoPago() de la superclase.
        // Línea 33
        return obtenerSalarioBase() + super.obtenerMontoPago(); 
    } // fin del método obtenerMontoPago (antes ingresos)

    // devuelve representación String de un objeto EmpleadoBaseMasComision
    @Override
    public String toString()
    {
        return String.format( "empleado con sueldo base y comision: %s\n%s: $%,.2f",
            super.toString(),
            "salario base", obtenerSalarioBase() );
    } // fin de la clase EmpleadoBaseMasComision
} // fin de la clase EmpleadoBaseMasComision