package Deitel.cap10;

//Stub para la clase Pantalla (Fig. 10.21, línea 9)
class Pantalla {
 // Implementación detallada omitida por simplicidad
} 

//Stub para la clase BaseDatosBanco (Fig. 10.21, línea 10)
class BaseDatosBanco {
 // Implementación detallada omitida por simplicidad
} 

//--- CLASE Transaccion CORREGIDA ---

//Fig. 10.21: Transaccion.java (CORREGIDO Y FUNCIONAL)
//La clase abstracta Transaccion representa una transacción con el ATM
public abstract class Transaccion
{
 // atributos (Líneas 9 y 10 corregidas por la adición de los stubs)
 private int numeroCuenta;      // indica la cuenta involucrada
 private Pantalla pantalla;     // la pantalla del ATM
 private BaseDatosBanco baseDatosBanco; // base de datos de información de las cuentas

 // --- Constructor Modificado (Líneas 15, 18, 19, 31, 33, 37, 39 se refieren al constructor) ---

 // El constructor recibe los componentes del ATM y los asigna (Línea 15)
 public Transaccion(int numeroCuentaUsuario, Pantalla pantallaATM, BaseDatosBanco baseDatos) 
 {
     this.numeroCuenta = numeroCuentaUsuario; // Línea 18
     this.pantalla = pantallaATM;             // Línea 19
     this.baseDatosBanco = baseDatos;         // Línea 31
 } // fin del constructor Transaccion con argumentos (Línea 33)

 // --- Métodos Accesores (Getters) ---

 // devuelve el número de cuenta
 public int obtenerNumeroCuenta()
 {
     return numeroCuenta;
 } // fin del método obtenerNumeroCuenta

 // devuelve referencia a la pantalla
 public Pantalla obtenerPantalla()
 {
     return pantalla;
 } // fin del método obtenerPantalla

 // devuelve referencia a la base de datos del banco
 public BaseDatosBanco obtenerBaseDatosBanco() // Línea 37
 {
     return baseDatosBanco; // Línea 39
 } // fin del método obtenerBaseDatosBanco

 // método abstracto sobrescrito por las subclases
 public abstract void ejecutar();
} // fin de la clase Transaccion