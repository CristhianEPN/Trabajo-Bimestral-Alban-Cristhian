package Deitel.cap10;

//Fig. 10.22: Retiro.java
//Se generó usando los diagramas de clases en las figuras 10.21 y 10.22
//Archivo: Retiro.java
class Teclado {}
class DispensadorEfectivo {}
//--- FIN STUBS ---

//Fig. 10.22: Retiro.java (CORREGIDO)
//Se generó usando los diagramas de clases en las figuras 10.21 y 10.22
public class Retiro extends Transaccion
{
 // atributos
 private double monto;     // monto a retirar
 private Teclado teclado;  // referencia al teclado (Línea 9: Requiere Teclado stub)
 private DispensadorEfectivo dispensadorEfectivo; // referencia al dispensador de efectivo (Línea 10: Requiere DispensadorEfectivo stub)

 // --- Constructor Modificado ---
 // Recibe los argumentos necesarios para la superclase (ATM) y para la subclase (Retiro)
 public Retiro(int numeroCuentaUsuario, Pantalla pantallaATM, 
               BaseDatosBanco baseDatos, Teclado tecladoATM, 
               DispensadorEfectivo dispensador)
 {
     // LLAMADA SUPER CORREGIDA (Línea 13: Causa el error original)
     super(numeroCuentaUsuario, pantallaATM, baseDatos); 
     
     // Inicializa los atributos propios de Retiro
     this.teclado = tecladoATM;
     this.dispensadorEfectivo = dispensador;
     // El monto se suele obtener en ejecutar(), pero lo incluimos si es necesario inicializar
     this.monto = 0.0; 
 } // fin del constructor de Retiro con argumentos

 // método que sobrescribe a ejecutar
 @Override
 public void ejecutar() // Línea 15: Método abstracto de Transaccion
 {
     // Lógica de Retiro (Obtener monto, verificar saldo, dispensar efectivo)
 } // fin del método ejecutar
} // fin de la clase Retiro