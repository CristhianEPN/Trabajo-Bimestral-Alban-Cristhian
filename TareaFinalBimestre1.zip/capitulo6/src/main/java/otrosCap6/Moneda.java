package otrosCap6;
import java.util.Random;

/**
 * Clase que simula el lanzamiento de una moneda.
 * Ejercicio 6.5
 * 
 * @author Christian Cuaspa
 * @version 1.0
 */
public class Moneda {
private Random random;
    //Uso de Ramdom para agilizar la generación de número aleatorios
    public Moneda() {
        random = new Random();
    }
    

    //Simulación de lanzamineto d ela moneda
    public String obtenerCara() {
        // Genera 0 o 1 aleatoriamente
        int resultado = random.nextInt(2);
        
        if (resultado == 0) {
            return "cara";
        } else {
            return "cruz";
        }
    }
    
    // Metodo main para probar la Clase Moneda
    public static void main(String[] args) {
        System.out.println("=== Lanzamiento de la moneda ===\n");
        
        Moneda moneda = new Moneda();
        System.out.println("Se lanza la moneda 2 veces: \n");
        for (int i = 1; i <= 2; i++) {
            String resultado = moneda.obtenerCara();
            System.out.println("Lanzamiento " + i + ": " + resultado);
        }
    }
}
