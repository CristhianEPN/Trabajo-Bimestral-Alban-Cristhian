package otrosCap6;
/**
 * Clase que simula el método de adivinación del I Ching usando monedas.
 * Ejercicio 6.6
 * 
 * @author Christian Cuaspa
 * @version 1.0
 */
public class IChing {
	private Moneda[] monedas;
    
	//Constructor
    public IChing() {
        monedas = new Moneda[3];
        for (int i = 0; i < 3; i++) {
            monedas[i] = new Moneda();
        }
    }
    /**
     * Lanza 3 monedas y determina el tipo de línea del hexagrama.
     * 
     * Reglas:
     * - 3 caras = Línea Yang antigua (cambiante) ----  o  ---- 
     * - 3 cruces = Línea Yin antigua (cambiante) ----  x  ----
     * - 2 caras y 1 cruz = Línea Yang joven ----------
     * - 2 cruces y 1 cara = Línea Yin joven ----    ----
     */
    
    public String lanzarMonedas() {
        int contadorCaras = 0;
        int contadorCruces = 0;
        
        // Lanzar las 3 monedas
        for (int i = 0; i < 3; i++) {
            String resultado = monedas[i].obtenerCara();
            if (resultado.equals("cara")) {
                contadorCaras++;
            } else {
                contadorCruces++;
            }
        }
        
        // Revisión en base al ejercicio 6.8
        // Uso de "var"
        //USANDO var
        //public String lanzarMonedas() {
        //    var contadorCaras = 0;
        //    var contadorCruces = 0;
            
        //    for (var i = 0; i < 3; i++) {
        //        var resultado = monedas[i].obtenerCara();
        //    .....
        
        // Determinar el tipo de línea según los resultados
        if (contadorCaras == 3) {
            return "Línea Yang antigua: ----  o  ----";
        } else if (contadorCruces == 3) {
            return "Línea Yin antigua:  ----  x  ----";
        } else if (contadorCaras == 2) {
            return "Línea Yang joven:     ----------";
        } else { // contadorCruces == 2
            return "Línea Yin joven:     ----    ----";
        }
    }
    
    // Metodo main para poner a Prueba la clase IChing
    public static void main(String[] args) {
        System.out.println("=== SIMULACIÓN DEL ICHING ===\n");
        System.out.println("Lanzando 3 monedas para generar líneas del hexagrama........\n");
        
        IChing iching = new IChing();
        
        // Simular 10 lanzamientos
        System.out.println("--- 10 lanzamientos de ejemplo ---");
        for (int i = 1; i <= 10; i++) {
            String linea = iching.lanzarMonedas();
            System.out.println("Lanzamiento " + i + ": " + linea);
        }
        
        // Desarrollo del ejercicio 6.7 con el mismo problema
        System.out.println("\n--- Generando un hexagrama completo (6 líneas)......... ---");
        System.out.println("Leyendo de abajo hacia arriba:\n");
        
        String[] hexagrama = new String[6];
        for (int i = 0; i < 6; i++) {
            hexagrama[i] = iching.lanzarMonedas();
        }
        
        // Mostrar el hexagrama de abajo hacia arriba
        for (int i = 5; i >= 0; i--) {
            System.out.println("Línea " + (i + 1) + ": " + hexagrama[i]);
        }

    }
}
