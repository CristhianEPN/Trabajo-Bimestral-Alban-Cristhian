package Persons.capitulo6;
/*
*@author Christian Cuaspa
*@Version 3.0
*/
public class Curso {
	private String nombreCurso;
	private String Tutor;
	private int numParticipantesActuales;
	private int maximoParticipantes;
	private int costPerPerson;
	
	//Constructor
	
	public Curso(String nombreCurso, String Tutor, int numParticipantesActuales, int maximoParticipantes) {
        this.nombreCurso = nombreCurso;
        this.Tutor = Tutor;
        this.numParticipantesActuales = 30;
        this.numParticipantesActuales = 0;
        //Se añade nuevo argumento y se le asigna un valor.
        this.costPerPerson=15;
        
    }
	
	//Aplicar getters and setters

	public String getNombreCurso() {
		return nombreCurso;
	}

	public void setNombreCurso(String nombreCurso) {
		this.nombreCurso = nombreCurso;
	}

	public String getTutor() {
		return Tutor;
	}

	public void setTutor(String tutor) {
		Tutor = tutor;
	}

	public int getNumParticipantesActuales() {
		return numParticipantesActuales;
	}

	public void setNumParticipantesActuales(int numParticipantesActuales) {
		this.numParticipantesActuales = numParticipantesActuales;
	}

	public int getMaximoParticipantes() {
		return maximoParticipantes;
	}

	public void setMaximoParticipantes(int maximoParticipantes) {
		this.maximoParticipantes = maximoParticipantes;
	}
	
	//Se genran los getters and setters para el ejercicio 6.2
	public int getCostPerPerson() {
		return costPerPerson;
	}

	public void setCostPerPerson(int costPerPerson) {
		this.costPerPerson = costPerPerson;
	}

	// Para verificar el número de participantes
	public void MaximoParticipantes(int maximoPartcipantes) {
        if (maximoParticipantes < this.numParticipantesActuales) {
            throw new IllegalArgumentException(
                "El máximo de participantes (" + maximoParticipantes + 
                ") no puede ser menor que el número actual de participantes (" + 
                this.numParticipantesActuales + ")"
            );
        }
        if (maximoParticipantes <= 0) {
            throw new IllegalArgumentException(
                "El máximo de participantes debe ser mayor que 0"
            );
        }
        this.maximoParticipantes = maximoParticipantes;
    }
	
    @Override
    public String toString() {
        return "Curso: " + nombreCurso +
               "\nTutor: " + Tutor +
               "\nParticipantes: " + numParticipantesActuales + "/" + maximoParticipantes;
    }
    
    // Desarrollo del ejercio 6.2 (Añadir un nuevo método)
    public double discountedCostPerPerson(int percentDiscount) {
        double discount = percentDiscount / 100.0;  //Representa el porcentaje de descuento en decimal
        double discountedCost = costPerPerson * (1 - discount);
        return discountedCost;
    }
    
    //Desarrollo del ejercicio 6.4
    //Constante que contiene el nombre de la empresa
    public static final String COMPANY_NAME = "Academia TechLearn";
    
    // Nuevo costo por persona
    public void setCostPerPerson(double costPerPerson) {
        if (costPerPerson < 0) {
            throw new IllegalArgumentException("El costo por persona no puede ser negativo");
        }
        this.costPerPerson = 15;
        
    }
    
    //Calculo del costo por persona
    public static double calculateCostPerPerson(double flatRate, int numberOfParticipants) {
        if (numberOfParticipants <= 0) {
            throw new IllegalArgumentException("El número de participantes debe ser mayor que 0");
        }
        return flatRate / numberOfParticipants;
    }
  
}
