package Persons.capitulo6;
/*
*@author Christian Cuaspa
*@Version 3.0
*/

public class App {
	public static void main(String[] args) {
	System.out.println("--- Definir variable del curso ---");
	Curso curso = new Curso("Programación orientada a Objetos","Paul Sayago", 30, 0);
    System.out.println(curso);
    System.out.println();
	// Para los getters
    System.out.println("--- Probar todos los getters ---");
    System.out.println("Nombre del curso: " + curso.getNombreCurso());
    System.out.println("Tutor: " + curso.getTutor());
    System.out.println("Participantes actuales: " + curso.getNumParticipantesActuales());
    System.out.println("Máximo de participantes: " + curso.getMaximoParticipantes());
    System.out.println();
    
    // Para los setters
    System.out.println("--- Probar con todos los setters ---");
    curso.setNombreCurso("Java Avanzado");
    curso.setTutor("Dr. Rodríguez");
    System.out.println("Curso después de modificaciones:");
    System.out.println(curso);
    
    System.out.println("=== TODAS LAS PRUEBAS COMPLETADAS ===");
    System.out.println();
    
    
    // Probar el nuevo método añadido del ejercicio 6.2
    System.out.println("--- Calcular valor del decuento ---");
    System.out.println("Costo original por persona: $" + curso.getCostPerPerson());
    
    int descuento10 = 10;
    double costoConDescuento10 = curso.discountedCostPerPerson(descuento10);
    System.out.println("Costo con " + descuento10 + "% descuento: $" + costoConDescuento10);
    
    int descuento25 = 25;
    double costoConDescuento25 = curso.discountedCostPerPerson(descuento25);
    System.out.println("Costo con " + descuento25 + "% descuento: $" + costoConDescuento25);
    
    int descuento50 = 50;
    double costoConDescuento50 = curso.discountedCostPerPerson(descuento50);
    System.out.println("Costo con " + descuento50 + "% descuento: $" + costoConDescuento50);
    
    System.out.println("=== TODAS LAS PRUEBAS COMPLETADAS ===");
    
    System.out.println();
    System.out.println("--- Calcular costo por persona (método estático) ---");
    //Mostrar valor de la constante
    System.out.println("Nombre de la empresa: " + Curso.COMPANY_NAME);
    
    double tarifaPlana1 = 5000.0;
    int participantes1 = 20;
    double costoPorPersona1 = curso.calculateCostPerPerson(tarifaPlana1, participantes1);
    System.out.println("Tarifa plana: $" + tarifaPlana1);
    System.out.println("Participantes: " + participantes1);
    System.out.println("Costo por persona: $" + costoPorPersona1);
    System.out.println();

  }
	
}
